# Atualização Diferente dos Normais (Android Todo Tempo)

## Como usar (tudo pelo GitHub, sem computador)
1. No **seu** repositório (fork do espeak-ng, de preferência **privado**), na branch `android`
   (commit 00ddddad), envie as pastas `.github/workflows/`, `patch/` e `vozes/`.
2. **Chave permanente (uma vez só):** Actions > "Criar chave de assinatura" > Run workflow
   (digite uma senha). Baixe o artefato `chave-de-assinatura`. Em Settings > Secrets and variables >
   Actions, crie: `KEYSTORE_BASE64` (conteúdo de `chave.base64.txt`), `KEYSTORE_PASSWORD`,
   `KEY_ALIAS` (diferente) e `KEY_PASSWORD` (a mesma senha). Guarde o `chave.jks` e a senha em local seguro:
   sem eles, ninguém consegue atualizar o app por cima.
3. Actions > "Diferente dos Normais - compilar e assinar" > Run workflow. Baixe o artefato
   `apk-diferente-dos-normais`: o APK já sai assinado.

## Atualizações futuras (vozes novas)
Você me envia os arquivos das vozes (.onnx e .onnx.json, em partes se forem grandes). Eu devolvo a pasta
`vozes/` atualizada. Você envia ao repositório e roda o workflow. O número da versão sobe sozinho,
então o APK novo instala por cima do anterior e as vozes novas já aparecem prontas em
**Vozes neurais**: é só escolher a voz de cada idioma e usar. Não apague o repositório e não troque a chave.

## Vozes incluídas
- Miro (português do Brasil, qualidade alta): pasta `vozes/Miro-high/`, modelo dividido em 3 partes de cerca de 21 MB para caber no envio pelo navegador. O nome "Miro" vem do nome da pasta (`Miro-high`), por isso não renomeie a pasta. Licença CC BY-NC-SA 4.0 (uso não comercial, mantenha o arquivo `LICENCA.txt`).

## O que a atualização faz
- Marca: nome "eSpeak tts Diferente dos normais" e pacote próprio `br.com.androidtodotempo.diferentedosnormais`
  (mudar em `patch/aplicar.py`, linhas do topo).
- Tela de boas-vindas com tutorial e botões Entrar e Sair (só na primeira vez; dá para rever depois).
- Menu Android Todo Tempo com os seus links de YouTube, WhatsApp e Telegram (e o botão de feedback do Sobre
  também abre o seu grupo). Botão Vozes do sistema. Tudo em Backup e sobre.
- Todas as telas, mensagens, avisos e listas em português do Brasil (todos os cerca de 500 textos do app, inclusive plurais, prévias de voz e resumos de ligado/desligado).
- Vozes neurais incluídas no app: instalam sozinhas ao abrir/atualizar o app e as vozes neurais são ligadas
  na primeira vez. Sem baixar nem importar nada.
- Dicionários importados, lado a lado (Configurações > Dicionários importados): cada arquivo importado vira um
  dicionário separado, com o nome do arquivo. Pode importar quantos quiser, de uma vez só (seleção múltipla), sem
  conflito: um não apaga nem mistura com o outro. Toque num dicionário para marcá-lo (pode marcar quantos quiser). Com 1 ou mais marcados aparece o botão Compartilhar
  (envia os arquivos para qualquer aplicativo); com 2 ou mais aparece também Excluir (confirmação: Sim ou Não, depois OK ou Cancelar).
  Toque e segure para Ativar/Desativar, Excluir ou Renomear um só. As palavras do Dicionário do
  usuário têm prioridade; entre os importados vale a ordem de importação. O botão "Importar arquivo" do
  Dicionário do usuário também cria um dicionário separado.
- Formatos lidos (testados com os seus arquivos de exemplo): CFD/BIN do Eloquence e do Vocalizer (UTF-16, inclusive
  arquivos com vários dicionários juntos e frases para silenciar), dict.txt da RH Voice (com `(x=y)` e `{,s}`),
  replaces.yaml do Multi TTS (regras desativadas lá ficam de fora), arquivos .zip com qualquer um deles dentro, e
  também NVDA, texto com TAB, `palavra=pronúncia`, `->`, `=>`, `;`, `,`, `|`, CSV, JSON, XML e seções `[main]`.
- Já existiam no app: velocidade, volume, tom e variação de tom; leitura de emojis; dicionário com criar/editar/compartilhar.

## O que NÃO está garantido
- A voz CereProc Gabriel foi descartada por enquanto (formato .voice do motor CereVoice, o app só lê Piper .onnx).
- Vozes neurais: a lista de download mostra somente português do Brasil (Faber e Cadu, as duas mantidas no catálogo). Para voltar a ver todos os idiomas, troque SOMENTE_PT_BR para false em PtBrOnly.java.
- O dicionário da Letícia: ainda não recebi um exemplo dela. Se o arquivo não for lido, envie e eu ajusto.
- Backup do app não inclui os dicionários importados (só as palavras do Dicionário do usuário).
- As vozes Cador, Jeff e Fábio ainda não estão no pacote: eu não recebi os arquivos. Envie e eu incluo.
- Nada foi compilado nem testado aqui. O 1º build pode acusar algum erro; mande o log que eu corrijo.
- O código-fonte que recebi é o 2.8 (3e802fd). O `aplicar.py` edita por pontos de ancoragem e para
  com aviso se algum não existir no 2.9 (00ddddad).
- A pasta em Android/data leva o nome do pacote, não o nome do app (limite do Android).
- O app novo tem outra assinatura e outro pacote que o `espeak-snapdragon-release.apk`: instala ao lado dele
  (ou desinstale o antigo). Daqui em diante, as atualizações sim instalam por cima umas das outras.
