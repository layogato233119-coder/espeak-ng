/*
 * Diferente dos Normais / Android Todo Tempo.
 * Importador universal de dicionarios: converte listas de palavras de varios formatos
 * (texto com tabulacao, "palavra=pronuncia", "->", ";", ",", "|", CSV, JSON, XML,
 * secoes [main]/[root]/[abbr], codificacao UTF-8/UTF-16/Windows-1252) para o formato
 * que o importador do app ja entende. GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class DictionaryFormats {
    private static final String[] PATTERN_KEYS = {"pattern", "word", "palavra", "from", "original", "text",
            "grapheme", "orth", "term", "termo", "key", "source", "src", "entrada"};
    private static final String[] REPLACEMENT_KEYS = {"replacement", "pronunciation", "pronuncia", "pron", "spoken",
            "fala", "to", "alias", "sub", "substituicao", "phonetic", "fonetica", "value", "target", "saida"};
    private static final Pattern SECTION = Pattern.compile("^\\[([^\\]]{1,40})\\]$");
    private static final Pattern ATTR = Pattern.compile("([A-Za-z_:-]+)\\s*=\\s*\"([^\"]*)\"");
    private static final Pattern ELEMENT_ATTRS = Pattern.compile(
            "<(?:entry|item|word|lexeme|e|rule|replace|sub|alias)\\b([^>]*?)/?>", Pattern.CASE_INSENSITIVE);
    private static final Pattern ELEMENT_PAIR = Pattern.compile(
            "<(?:entry|item|lexeme|rule|e)\\b[^>]*>\\s*<(word|grapheme|orth|from|text|palavra|pattern)>(.*?)</\\1>\\s*"
                    + "<(pron|pronunciation|replacement|phoneme|to|sub|alias|spoken|fala)>(.*?)</\\3>",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    private DictionaryFormats() {
    }

    static byte[] readAll(InputStream in, int max) throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final byte[] buf = new byte[32 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            if (out.size() > max) {
                throw new IOException("arquivo grande demais");
            }
        }
        return out.toByteArray();
    }

    static String displayName(Context context, Uri uri) {
        try (Cursor c = context.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME},
                null, null, null)) {
            if (c != null && c.moveToFirst() && c.getString(0) != null) {
                return c.getString(0);
            }
        } catch (RuntimeException ignored) {
            // sem nome: a secao [..] do arquivo ainda vale
        }
        return "";
    }

    /**
     * Converte para linhas no formato do app (padrao TAB fala TAB comentario TAB 0 TAB 2), ou devolve
     * null quando o arquivo ja e nativo (formato NVDA com 5 colunas, JSON exportado por este app)
     * ou nao tem nenhuma entrada reconhecivel (o importador mostra "nenhuma regra encontrada").
     */
    static byte[] normalize(byte[] raw, String fileName) {
        final String text = decode(raw);
        final String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.startsWith("[") && trimmed.contains("\"pattern\"")) {
            return null;
        }
        final String baseCategory = categoryFromName(fileName);
        final List<String[]> rows = new ArrayList<>();
        boolean done = false;
        final List<DictionaryParsers.Row> special = DictionaryParsers.parse(text);
        if (special != null && !special.isEmpty()) {
            for (DictionaryParsers.Row r : special) {
                rows.add(new String[]{r.pattern, r.replacement,
                        "main".equals(r.category) ? baseCategory : r.category, r.type});
            }
            done = true;
        }
        if (!done && (trimmed.startsWith("{") || trimmed.startsWith("["))) {
            try {
                final Object root = trimmed.startsWith("{") ? new JSONObject(trimmed) : new JSONArray(trimmed);
                collectJson(root, baseCategory, rows, 0);
                done = true;
            } catch (Exception ignored) {
                // nao era JSON (por exemplo, uma secao [main] de arquivo de texto)
            }
        }
        if (!done && trimmed.startsWith("<")) {
            collectXml(trimmed, baseCategory, rows);
            done = true;
        }
        if (!done) {
            if (isNativeNvda(text)) {
                return null;
            }
            collectLines(text, baseCategory, rows);
        }
        if (rows.isEmpty()) {
            return null;
        }
        final StringBuilder out = new StringBuilder("# convertido pelo importador universal\n");
        for (String[] r : rows) {
            final String comment = "main".equals(r[2]) ? "importado"
                    : "eSpeakAndroid {\"category\":\"" + r[2] + "\"}";
            out.append(clean(r[0])).append('\t').append(clean(r[1])).append('\t')
                    .append(comment).append("\t0\t").append(r.length > 3 ? r[3] : "2").append('\n');
        }
        return out.toString().getBytes(StandardCharsets.UTF_8);
    }

    /** Le qualquer formato suportado e devolve as regras prontas (lista vazia se nao achar nenhuma). */
    static List<UserDictionary> parseToRules(byte[] raw, String fileName) {
        final List<UserDictionary> out = new ArrayList<>();
        final String text0 = decode(raw);
        final String t = text0.trim();
        if (t.startsWith("[") && t.contains("\"pattern\"")) {
            try {
                final JSONArray arr = new JSONArray(t);
                for (int i = 0; i < arr.length(); i++) {
                    final UserDictionary r = UserDictionary.fromJson(arr.getJSONObject(i));
                    if (r != null && r.isValid()) {
                        out.add(r);
                    }
                }
                return out;
            } catch (Exception ignored) {
                // cai para os outros leitores
            }
        }
        final byte[] conv = normalize(raw, fileName);
        final String text = conv != null ? new String(conv, StandardCharsets.UTF_8) : text0;
        for (String line : text.split("\r\n|\n|\r")) {
            final UserDictionary r = UserDictionaryManager.parseDicLine(line);
            if (r != null && r.isValid()) {
                out.add(r);
            }
        }
        return out;
    }

    static String decode(byte[] raw) {
        if (raw.length >= 3 && (raw[0] & 0xFF) == 0xEF && (raw[1] & 0xFF) == 0xBB && (raw[2] & 0xFF) == 0xBF) {
            return new String(raw, 3, raw.length - 3, StandardCharsets.UTF_8);
        }
        if (raw.length >= 2 && (raw[0] & 0xFF) == 0xFF && (raw[1] & 0xFF) == 0xFE) {
            return new String(raw, 2, raw.length - 2, StandardCharsets.UTF_16LE).replace("\u0000", "");
        }
        if (raw.length >= 2 && (raw[0] & 0xFF) == 0xFE && (raw[1] & 0xFF) == 0xFF) {
            return new String(raw, 2, raw.length - 2, StandardCharsets.UTF_16BE).replace("\u0000", "");
        }
        if (raw.length >= 4 && raw[0] == 0 && raw[1] != 0 && raw[2] == 0) {
            return new String(raw, StandardCharsets.UTF_16BE).replace("\u0000", "");
        }
        if (raw.length >= 4 && raw[1] == 0 && raw[0] != 0 && raw[3] == 0) {
            return new String(raw, StandardCharsets.UTF_16LE).replace("\u0000", "");
        }
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(raw)).toString();
        } catch (CharacterCodingException e) {
            try {
                return new String(raw, Charset.forName("windows-1252"));
            } catch (RuntimeException e2) {
                return new String(raw, StandardCharsets.ISO_8859_1);
            }
        }
    }

    private static boolean isNativeNvda(String text) {
        int total = 0;
        int five = 0;
        for (String line : text.split("\r\n|\n|\r")) {
            final String l = line.trim();
            if (l.isEmpty() || l.startsWith("#")) {
                continue;
            }
            total++;
            if (line.split("\t", -1).length >= 5) {
                five++;
            }
        }
        return total > 0 && five * 2 > total;
    }

    private static void collectLines(String text, String baseCategory, List<String[]> rows) {
        String category = baseCategory;
        boolean first = true;
        for (String raw : text.split("\r\n|\n|\r")) {
            final String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#") || line.startsWith("//") || line.startsWith(";;")) {
                continue;
            }
            final Matcher section = SECTION.matcher(line);
            if (section.matches()) {
                category = categoryFromName(section.group(1));
                continue;
            }
            final String[] kv = splitLine(raw);
            if (kv == null) {
                continue;
            }
            if (first) {
                first = false;
                if (isHeader(kv[0], kv[1])) {
                    continue;
                }
            }
            add(rows, kv[0], kv[1], category);
        }
    }

    private static boolean isHeader(String a, String b) {
        final String x = a.toLowerCase(Locale.ROOT);
        final String y = b.toLowerCase(Locale.ROOT);
        return (x.equals("palavra") || x.equals("word") || x.equals("pattern") || x.equals("original")
                || x.equals("texto") || x.equals("termo"))
                && (y.startsWith("pron") || y.startsWith("fala") || y.startsWith("replace")
                || y.startsWith("subst") || y.startsWith("fon"));
    }

    private static String[] splitLine(String raw) {
        String line = raw.trim();
        String[] delimiters = {"\t", "=>", "->", "=", "|", ";", ","};
        for (String d : delimiters) {
            int idx;
            if (line.startsWith("\"") && (d.equals(",") || d.equals(";"))) {
                final int close = line.indexOf('"', 1);
                if (close < 0) {
                    continue;
                }
                idx = line.indexOf(d, close);
            } else {
                idx = line.indexOf(d);
            }
            if (idx > 0) {
                final String left = unquote(line.substring(0, idx).trim());
                final String right = unquote(line.substring(idx + d.length()).trim());
                if (!left.isEmpty() && !right.isEmpty()) {
                    return new String[]{left, right};
                }
            }
        }
        // Ultimo recurso (formatos "palavra pronuncia" separados por espaco): so vale com 2 palavras
        final String[] tokens = line.split("\\s+");
        if (tokens.length == 2) {
            return new String[]{unquote(tokens[0]), unquote(tokens[1])};
        }
        return null;
    }

    private static String unquote(String s) {
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            return s.substring(1, s.length() - 1).replace("\"\"", "\"");
        }
        return s;
    }

    private static void collectJson(Object node, String category, List<String[]> rows, int depth) {
        if (depth > 4) {
            return;
        }
        if (node instanceof JSONArray) {
            final JSONArray array = (JSONArray) node;
            for (int i = 0; i < array.length(); i++) {
                final Object item = array.opt(i);
                if (item instanceof JSONObject) {
                    final JSONObject o = (JSONObject) item;
                    final String p = firstString(o, PATTERN_KEYS);
                    final String r = firstString(o, REPLACEMENT_KEYS);
                    if (p != null && r != null) {
                        add(rows, p, r, category);
                    } else {
                        collectJson(o, category, rows, depth + 1);
                    }
                } else if (item instanceof JSONArray) {
                    final JSONArray pair = (JSONArray) item;
                    if (pair.length() >= 2 && pair.opt(0) instanceof String && pair.opt(1) instanceof String) {
                        add(rows, pair.optString(0), pair.optString(1), category);
                    }
                }
            }
        } else if (node instanceof JSONObject) {
            final JSONObject obj = (JSONObject) node;
            final Iterator<String> keys = obj.keys();
            boolean nested = false;
            final List<String> names = new ArrayList<>();
            while (keys.hasNext()) {
                names.add(keys.next());
            }
            for (String k : names) {
                final Object v = obj.opt(k);
                if (v instanceof JSONArray || v instanceof JSONObject) {
                    nested = true;
                    collectJson(v, categoryFromName(k).equals("main") ? category : categoryFromName(k), rows, depth + 1);
                }
            }
            if (!nested) {
                for (String k : names) {
                    final Object v = obj.opt(k);
                    if (v instanceof String) {
                        add(rows, k, (String) v, category);
                    }
                }
            }
        }
    }

    private static String firstString(JSONObject o, String[] keys) {
        for (String k : keys) {
            final String v = o.optString(k, null);
            if (v != null && !v.isEmpty()) {
                return v;
            }
        }
        return null;
    }

    private static void collectXml(String xml, String category, List<String[]> rows) {
        final Matcher pairs = ELEMENT_PAIR.matcher(xml);
        while (pairs.find()) {
            add(rows, unescape(pairs.group(2)), unescape(pairs.group(4)), category);
        }
        final Matcher elements = ELEMENT_ATTRS.matcher(xml);
        while (elements.find()) {
            String p = null;
            String r = null;
            final Matcher attrs = ATTR.matcher(elements.group(1));
            while (attrs.find()) {
                final String name = attrs.group(1).toLowerCase(Locale.ROOT);
                if (p == null && contains(PATTERN_KEYS, name)) {
                    p = unescape(attrs.group(2));
                } else if (r == null && contains(REPLACEMENT_KEYS, name)) {
                    r = unescape(attrs.group(2));
                }
            }
            if (p != null && r != null) {
                add(rows, p, r, category);
            }
        }
    }

    private static boolean contains(String[] keys, String name) {
        for (String k : keys) {
            if (k.equals(name)) {
                return true;
            }
        }
        return false;
    }

    private static String unescape(String s) {
        return s.trim().replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&apos;", "'").replace("&amp;", "&");
    }

    private static void add(List<String[]> rows, String pattern, String replacement, String category) {
        final String p = pattern == null ? "" : pattern.trim();
        final String r = replacement == null ? "" : replacement.trim();
        if (!p.isEmpty() && !r.isEmpty() && !p.equals(r)) {
            rows.add(new String[]{p, r, category});
        }
    }

    static String categoryFromName(String name) {
        final String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.contains("root") || n.contains("raiz")) {
            return "root";
        }
        if (n.contains("abbr") || n.contains("abrev")) {
            return "abbrev";
        }
        if (n.contains("char") || n.contains("carac")) {
            return "character";
        }
        return "main";
    }

    private static String clean(String s) {
        return s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }
}
