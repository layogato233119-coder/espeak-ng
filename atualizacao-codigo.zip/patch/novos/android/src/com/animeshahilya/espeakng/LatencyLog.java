/*
 * Diferente dos Normais / Android Todo Tempo.
 * Guarda quanto tempo cada fala leva entre o pedido do leitor de tela e o primeiro som,
 * para o "Exportar registro" mostrar a resposta ao toque no seu celular. GPL v3 ou posterior.
 */

package com.animeshahilya.espeakng;

import java.util.ArrayDeque;

final class LatencyLog {
    private static final int MAX = 40;
    private static final ArrayDeque<long[]> ENTRIES = new ArrayDeque<>(); // {ms, tamanho do texto, neural(1/0)}

    private static volatile boolean pending = false;
    private static long startNs;
    private static int textLength;
    private static boolean natural;

    private LatencyLog() {
    }

    /** Chamado quando o pedido de fala chega. */
    static synchronized void begin(int length) {
        startNs = System.nanoTime();
        textLength = length;
        natural = false;
        pending = true;
    }

    /** Chamado quando a voz neural vai falar este pedido. */
    static synchronized void markNatural() {
        natural = true;
    }

    /** Chamado a cada envio de audio; so a primeira vez depois de begin() conta. */
    static void firstSound() {
        if (!pending) {
            return;
        }
        synchronized (LatencyLog.class) {
            if (!pending) {
                return;
            }
            pending = false;
            record((System.nanoTime() - startNs) / 1000000L, textLength, natural);
        }
    }

    static synchronized void record(long ms, int length, boolean isNatural) {
        if (ENTRIES.size() >= MAX) {
            ENTRIES.removeFirst();
        }
        ENTRIES.addLast(new long[] {ms, length, isNatural ? 1 : 0});
    }

    /** Texto para o registro: resumo e a lista das ultimas falas (ms ate o primeiro som). */
    static synchronized String report() {
        final StringBuilder sb = new StringBuilder("--- latencia: ms do pedido ate o primeiro som ---\n");
        if (ENTRIES.isEmpty()) {
            return sb.append("(nenhuma fala registrada ainda)\n\n").toString();
        }
        final long[] all = new long[ENTRIES.size()];
        int i = 0;
        for (long[] e : ENTRIES) {
            all[i++] = e[0];
        }
        final long[] sorted = all.clone();
        java.util.Arrays.sort(sorted);
        sb.append("falas: ").append(all.length)
                .append(" | mediana ").append(sorted[sorted.length / 2]).append(" ms")
                .append(" | p90 ").append(sorted[Math.min(sorted.length - 1, (int) (sorted.length * 0.9))]).append(" ms")
                .append(" | maior ").append(sorted[sorted.length - 1]).append(" ms\n");
        for (long[] e : ENTRIES) {
            sb.append(e[2] == 1 ? "neural" : "eSpeak").append(" texto=").append(e[1]).append(" letras  ")
                    .append(e[0]).append(" ms\n");
        }
        return sb.append('\n').toString();
    }
}
