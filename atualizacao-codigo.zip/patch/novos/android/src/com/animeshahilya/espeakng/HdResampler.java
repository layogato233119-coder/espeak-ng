/*
 * Diferente dos Normais / Android Todo Tempo.
 * Converte o audio da voz neural (22,05 kHz, 16 kHz...) para 48 kHz com um filtro de boa qualidade
 * (polifasico, janela de Kaiser), em vez de deixar o Android fazer essa conversao com um metodo
 * simples. Mantem estado entre pedacos, entao as emendas entre frases ficam continuas. GPL v3 ou posterior.
 */

package com.animeshahilya.espeakng;

final class HdResampler {
    static final int OUT_RATE = 48000;
    private static final int TAPS = 32;          // amostras de entrada por fase
    private static final double KAISER_BETA = 9.0;
    private static final double CUTOFF = 0.46;   // fracao da taxa de entrada (Nyquist = 0,5)

    private final int inRate;
    private final int up;       // L
    private final int down;     // M
    private final float[] coef; // [fase * TAPS + k], ganho DC = 1 por fase
    private float[] buf = new float[0];
    private long bufStart = 0;  // indice global da amostra buf[0]
    private long outIndex = 0;  // proxima amostra de saida

    private HdResampler(int inRate) {
        this.inRate = inRate;
        final int g = gcd(inRate, OUT_RATE);
        this.up = OUT_RATE / g;
        this.down = inRate / g;
        this.coef = design(up, TAPS);
    }

    /** Null se nao precisar ou nao deve converter. */
    static HdResampler forRate(int inRate, boolean enabled) {
        if (!enabled || inRate < 8000 || inRate >= OUT_RATE) {
            return null;
        }
        try {
            return new HdResampler(inRate);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Quadros da taxa de entrada convertidos para a taxa de saida. */
    int toOutput(int frames) {
        return (int) (frames * (long) OUT_RATE / inRate);
    }

    private static int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    private static double bessel0(double x) {
        double sum = 1, term = 1;
        for (int k = 1; k < 50; k++) {
            term *= (x / (2 * k)) * (x / (2 * k));
            sum += term;
            if (term < 1e-12 * sum) break;
        }
        return sum;
    }

    private static float[] design(int up, int taps) {
        final int n = up * taps;
        final double c = (n - 1) / 2.0;
        final double fc = CUTOFF / up;            // ciclos por amostra da grade superamostrada
        final double i0 = bessel0(KAISER_BETA);
        final double[] h = new double[n];
        for (int j = 0; j < n; j++) {
            final double x = j - c;
            final double arg = 2 * fc * x;
            final double sinc = arg == 0 ? 1.0 : Math.sin(Math.PI * arg) / (Math.PI * arg);
            final double r = x / c;
            final double w = bessel0(KAISER_BETA * Math.sqrt(Math.max(0, 1 - r * r))) / i0;
            h[j] = sinc * w;
        }
        final float[] out = new float[n];
        for (int p = 0; p < up; p++) {
            double s = 0;
            for (int k = 0; k < taps; k++) s += h[p + k * up];
            for (int k = 0; k < taps; k++) out[p * taps + k] = (float) (h[p + k * up] / s);
        }
        return out;
    }

    /** PCM 16 bits mono little-endian na taxa de entrada -> o mesmo na taxa de 48 kHz. */
    byte[] process(byte[] pcm) {
        final int n = pcm.length / 2;
        if (n == 0) {
            return pcm;
        }
        // junta o resto do bloco anterior com a entrada nova
        final float[] all = new float[buf.length + n];
        System.arraycopy(buf, 0, all, 0, buf.length);
        for (int i = 0; i < n; i++) {
            all[buf.length + i] = (short) ((pcm[2 * i] & 0xff) | (pcm[2 * i + 1] << 8));
        }
        final long inEnd = bufStart + all.length;       // fim global (exclusivo)
        // saidas possiveis: as que so precisam de entrada ja disponivel
        long lastOut = (inEnd * up - 1) / down;          // maior n com floor(n*down/up) < inEnd
        final int count = (int) Math.max(0, lastOut - outIndex + 1);
        final byte[] out = new byte[count * 2];
        for (int o = 0; o < count; o++) {
            final long idx = (outIndex + o) * down;
            final long m = idx / up;                     // amostra de entrada mais recente
            final int phase = (int) (idx % up);
            // o filtro do pico: fase p usa x[m - k]
            double acc = 0;
            final int base = phase * TAPS;
            for (int k = 0; k < TAPS; k++) {
                final long gi = m - k;
                final long li = gi - bufStart;
                if (li >= 0 && li < all.length) {
                    acc += all[(int) li] * coef[base + k];
                }
            }
            long v = Math.round(acc);
            if (v > 32767) v = 32767;
            if (v < -32768) v = -32768;
            out[2 * o] = (byte) (v & 0xff);
            out[2 * o + 1] = (byte) ((v >> 8) & 0xff);
        }
        outIndex += count;
        // guarda so o historico necessario
        final long nextM = (outIndex * down) / up;
        final long keepFrom = Math.max(bufStart, nextM - TAPS);
        final int drop = (int) (keepFrom - bufStart);
        final float[] rest = new float[all.length - drop];
        System.arraycopy(all, drop, rest, 0, rest.length);
        buf = rest;
        bufStart = keepFrom;
        return out;
    }
}
