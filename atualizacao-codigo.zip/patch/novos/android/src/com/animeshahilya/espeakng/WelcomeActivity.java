/*
 * Diferente dos Normais / Android Todo Tempo.
 * Tela de boas-vindas com tutorial, botoes Entrar e Sair.
 * GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class WelcomeActivity extends AppCompatActivity {
    static final String EXTRA_REVIEW = "review";
    private static final String PREFS = "todo_tempo";
    private static final String KEY_SEEN = "welcome_seen_v1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final boolean review = getIntent().getBooleanExtra(EXTRA_REVIEW, false);
        final SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!review && prefs.getBoolean(KEY_SEEN, false)) {
            openSettings();
            return;
        }
        setTitle(R.string.welcome_title);

        final int pad = dp(20);
        final LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(pad, pad, pad, pad);

        final TextView title = new TextView(this);
        title.setText(R.string.welcome_title);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        ViewCompat.setAccessibilityHeading(title, true);
        column.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final TextView body = new TextView(this);
        body.setText(R.string.welcome_body);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        body.setLineSpacing(0f, 1.25f);
        body.setPadding(0, dp(16), 0, dp(16));
        column.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final Button enter = new Button(this);
        enter.setText(R.string.welcome_enter);
        enter.setOnClickListener(v -> {
            prefs.edit().putBoolean(KEY_SEEN, true).apply();
            if (review) {
                finish();
            } else {
                openSettings();
            }
        });
        column.addView(enter, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final Button leave = new Button(this);
        leave.setText(R.string.welcome_exit);
        leave.setOnClickListener(v -> finishAffinity());
        column.addView(leave, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(column);
        ViewCompat.setOnApplyWindowInsetsListener(scroll, (View v, WindowInsetsCompat insets) -> {
            final Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        setContentView(scroll);
    }

    private void openSettings() {
        startActivity(new Intent(this, TtsSettingsActivity.class));
        finish();
    }

    private int dp(int value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()));
    }
}
