/*
 * Diferente dos Normais / Android Todo Tempo.
 * Dicionarios importados: cada arquivo importado vira um dicionario SEPARADO (um arquivo proprio
 * dentro do app), que pode ser ativado, desativado, renomeado ou excluido sem mexer nos outros.
 * Todos os ativados funcionam juntos, sem conflito. As palavras do proprio usuario (Dicionario do
 * usuario) sao aplicadas antes e tem prioridade. GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import android.content.Context;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

final class DictionaryPacks {
    /** Um dicionario importado (copia somente leitura para a tela). */
    static final class Pack {
        final String id;
        final String name;
        final boolean active;
        final int count;

        Pack(String id, String name, boolean active, int count) {
            this.id = id;
            this.name = name;
            this.active = active;
            this.count = count;
        }
    }

    static final class ImportResult {
        int dictionaries;
        int rules;
        String name = "";
    }

    private static final String DIR = "dn_pacotes";
    private static final String INDEX = "indice.json";

    private static volatile DictionaryPacks sInstance;

    private final File dir;
    private final List<Pack> packs = new ArrayList<>();
    private final Map<String, List<UserDictionary>> rulesById = new HashMap<>();
    private final ConcurrentHashMap<String, List<UserDictionary>> langCache = new ConcurrentHashMap<>();
    private List<UserDictionary> characterRules = null;

    private DictionaryPacks(File filesDir) {
        dir = new File(filesDir, DIR);
        dir.mkdirs();
        loadIndex();
    }

    static DictionaryPacks get(Context context) {
        return get(EspeakApp.requireStorageContext(context.getApplicationContext()).getFilesDir());
    }

    static DictionaryPacks get(File filesDir) {
        final DictionaryPacks existing = sInstance;
        if (existing != null) {
            return existing;
        }
        synchronized (DictionaryPacks.class) {
            if (sInstance == null) {
                sInstance = new DictionaryPacks(filesDir);
            }
            return sInstance;
        }
    }

    // ---- lista --------------------------------------------------------------------------

    synchronized List<Pack> list() {
        return new ArrayList<>(packs);
    }

    private int indexOf(String id) {
        for (int i = 0; i < packs.size(); i++) {
            if (packs.get(i).id.equals(id)) {
                return i;
            }
        }
        return -1;
    }

    private String uniqueName(String base, String ignoreId) {
        String name = base;
        int n = 2;
        while (true) {
            boolean taken = false;
            for (Pack p : packs) {
                if (!p.id.equals(ignoreId) && p.name.equalsIgnoreCase(name)) {
                    taken = true;
                    break;
                }
            }
            if (!taken) {
                return name;
            }
            name = base + " (" + n + ")";
            n++;
        }
    }

    // ---- criar / alterar / excluir ----------------------------------------------------------

    synchronized Pack addPack(String name, List<UserDictionary> rules) throws IOException {
        if (rules == null || rules.isEmpty()) {
            return null;
        }
        final String id = "p" + Long.toString(System.currentTimeMillis(), 36)
                + Integer.toString(packs.size(), 36);
        final File file = new File(dir, id + ".dic");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            for (UserDictionary r : rules) {
                w.write(UserDictionaryManager.toDicLine(r));
            }
        }
        final Pack pack = new Pack(id, uniqueName(name, id), true, rules.size());
        packs.add(pack);
        rulesById.put(id, new ArrayList<>(rules));
        saveIndex();
        invalidate();
        return pack;
    }

    /** Arquivo do dicionario (para compartilhar), ou null se nao existir. */
    synchronized File fileOf(String id) {
        final File file = new File(dir, id + ".dic");
        return file.isFile() ? file : null;
    }

    synchronized void delete(String id) {
        final int i = indexOf(id);
        if (i < 0) {
            return;
        }
        packs.remove(i);
        rulesById.remove(id);
        new File(dir, id + ".dic").delete();
        saveIndex();
        invalidate();
    }

    synchronized void setActive(String id, boolean active) {
        final int i = indexOf(id);
        if (i < 0) {
            return;
        }
        final Pack p = packs.get(i);
        packs.set(i, new Pack(p.id, p.name, active, p.count));
        saveIndex();
        invalidate();
    }

    synchronized void rename(String id, String newName) {
        final int i = indexOf(id);
        final String clean = cleanText(newName);
        if (i < 0 || clean.isEmpty()) {
            return;
        }
        final Pack p = packs.get(i);
        packs.set(i, new Pack(p.id, uniqueName(clean, id), p.active, p.count));
        saveIndex();
    }

    // ---- importar -----------------------------------------------------------------------

    static ImportResult importUri(Context context, Uri uri) throws IOException {
        final String display = DictionaryFormats.displayName(context, uri);
        final byte[] raw;
        try (InputStream is = context.getContentResolver().openInputStream(uri)) {
            if (is == null) {
                throw new IOException("arquivo indisponivel");
            }
            raw = DictionaryFormats.readAll(is, 64 << 20);
        }
        return importBytes(get(context), raw, display);
    }

    static ImportResult importBytes(DictionaryPacks packs, byte[] raw, String display) throws IOException {
        final List<UserDictionary> rules;
        if (raw.length > 4 && raw[0] == 'P' && raw[1] == 'K' && raw[2] == 3 && raw[3] == 4) {
            rules = new ArrayList<>();
            try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(raw))) {
                ZipEntry entry;
                while ((entry = zin.getNextEntry()) != null) {
                    if (entry.isDirectory()) {
                        continue;
                    }
                    try {
                        final byte[] data = DictionaryFormats.readAll(zin, 32 << 20);
                        rules.addAll(DictionaryFormats.parseToRules(data, entry.getName()));
                    } catch (IOException ignored) {
                        // entrada grande demais ou ilegivel: as outras continuam
                    }
                }
            }
        } else {
            rules = DictionaryFormats.parseToRules(raw, display);
        }
        final ImportResult result = new ImportResult();
        final Pack pack = packs.addPack(cleanName(display), rules);
        if (pack != null) {
            result.dictionaries = 1;
            result.rules = pack.count;
            result.name = pack.name;
        }
        return result;
    }

    static String cleanName(String display) {
        String s = display == null ? "" : display;
        s = s.replaceAll("(?i)\\.(zip|dic|cfd|bin|txt|yaml|yml|json|csv|xml)(?![A-Za-z]).*$", "");
        s = cleanText(s.replace('_', ' '));
        return s.isEmpty() ? "Dicionário" : s;
    }

    private static String cleanText(String s) {
        String t = s == null ? "" : s.replaceAll("\\s+", " ").trim();
        return t.length() > 60 ? t.substring(0, 60).trim() : t;
    }

    // ---- aplicar na fala ---------------------------------------------------------------------

    /** Aplica as regras de todos os dicionarios ativados (em ordem de importacao). */
    String apply(String text, String language) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        final String key = language != null ? AsciiUtils.toAsciiLowerCase(language.trim()) : "";
        final List<UserDictionary> matching = matchingFor(key);
        if (matching.isEmpty()) {
            return text;
        }
        String result = text;
        for (UserDictionary rule : matching) {
            result = rule.apply(result);
        }
        return result;
    }

    /** Regras de caractere (leitura de uma letra ou simbolo isolado). */
    String applyCharacter(String text, String language) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        final String trimmed = text.trim();
        if (trimmed.isEmpty()) {
            return text;
        }
        for (UserDictionary rule : characterRulesList()) {
            if (rule.appliesToLanguage(language)) {
                final String pattern = rule.getPattern();
                final boolean same = rule.isCaseSensitive() ? pattern.equals(trimmed)
                        : pattern.equalsIgnoreCase(trimmed);
                if (same) {
                    return rule.apply(trimmed);
                }
            }
        }
        return text;
    }

    private synchronized List<UserDictionary> matchingFor(String key) {
        List<UserDictionary> cached = langCache.get(key);
        if (cached != null) {
            return cached;
        }
        final List<UserDictionary> out = new ArrayList<>();
        for (Pack p : packs) {
            if (!p.active) {
                continue;
            }
            for (UserDictionary r : rulesOf(p.id)) {
                if (!UserDictionary.CATEGORY_CHARACTER.equals(r.getCategory()) && r.appliesToLanguage(key)) {
                    out.add(r);
                }
            }
        }
        langCache.put(key, out);
        return out;
    }

    private synchronized List<UserDictionary> characterRulesList() {
        if (characterRules == null) {
            final List<UserDictionary> out = new ArrayList<>();
            for (Pack p : packs) {
                if (!p.active) {
                    continue;
                }
                for (UserDictionary r : rulesOf(p.id)) {
                    if (UserDictionary.CATEGORY_CHARACTER.equals(r.getCategory())) {
                        out.add(r);
                    }
                }
            }
            characterRules = out;
        }
        return characterRules;
    }

    private List<UserDictionary> rulesOf(String id) {
        List<UserDictionary> rules = rulesById.get(id);
        if (rules == null) {
            rules = new ArrayList<>();
            final File file = new File(dir, id + ".dic");
            if (file.exists()) {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        final UserDictionary r = UserDictionaryManager.parseDicLine(line);
                        if (r != null && r.isValid()) {
                            rules.add(r);
                        }
                    }
                } catch (IOException ignored) {
                    // dicionario ilegivel: fica vazio
                }
            }
            rulesById.put(id, rules);
        }
        return rules;
    }

    private void invalidate() {
        langCache.clear();
        characterRules = null;
    }

    // ---- indice ------------------------------------------------------------------------

    private void loadIndex() {
        final File file = new File(dir, INDEX);
        if (!file.exists()) {
            return;
        }
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            final StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            final JSONArray arr = new JSONArray(sb.toString());
            for (int i = 0; i < arr.length(); i++) {
                final JSONObject o = arr.getJSONObject(i);
                final String id = o.getString("id");
                if (new File(dir, id + ".dic").exists()) {
                    packs.add(new Pack(id, o.optString("name", "Dicionário"), o.optBoolean("active", true),
                            o.optInt("count", 0)));
                }
            }
        } catch (Exception ignored) {
            // indice danificado: recomeca vazio
        }
    }

    private void saveIndex() {
        try {
            final JSONArray arr = new JSONArray();
            for (Pack p : packs) {
                final JSONObject o = new JSONObject();
                o.put("id", p.id);
                o.put("name", p.name);
                o.put("active", p.active);
                o.put("count", p.count);
                arr.put(o);
            }
            final File tmp = new File(dir, INDEX + ".tmp");
            try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
                w.write(arr.toString());
            }
            final File file = new File(dir, INDEX);
            if (!tmp.renameTo(file)) {
                file.delete();
                tmp.renameTo(file);
            }
        } catch (Exception ignored) {
            // sem espaco: a lista fica so na memoria ate o proximo salvamento
        }
    }
}
