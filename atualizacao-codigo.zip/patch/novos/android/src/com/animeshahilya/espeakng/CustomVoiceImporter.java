/*
 * Diferente dos Normais / Android Todo Tempo.
 * Instala uma voz neural (Piper: .onnx + .onnx.json) na pasta de vozes do app.
 * Usado por BundledVoices para as vozes que vem dentro do APK.
 * GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import android.content.Context;
import android.content.Intent;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

final class CustomVoiceImporter {
    private CustomVoiceImporter() {
    }

    /**
     * Valida e instala uma voz. Devolve a chave da voz, ou null se ja estava instalada
     * (nesse caso o modelo nem e lido). A chave segue o padrao do catalogo ("pt_BR-nome")
     * para o app reconhecer o idioma.
     */
    static String install(Context storage, String name, InputStream model, InputStream config)
            throws IOException {
        final String json = new String(readAll(config, 8 << 20), StandardCharsets.UTF_8);
        final PiperVoiceConfig cfg;
        try {
            cfg = PiperVoiceConfig.parse("pt_BR-teste", json);
        } catch (Exception e) {
            throw new IOException("arquivo .json invalido");
        }
        if (!cfg.isSupported()) {
            throw new IOException("configuracao de voz nao suportada");
        }
        String code = cfg.languageCode;
        if (code == null || !code.matches("[a-z]{2,3}_[A-Z]{2}")) {
            final String family = cfg.languageFamily;
            if (family != null && family.matches("[a-z]{2,3}")) {
                code = family + "_" + ("pt".equals(family) ? "BR" : family.toUpperCase(Locale.ROOT));
            } else {
                code = "pt_BR";
            }
        }
        String safe = name.replaceAll("(?i)\\.onnx(\\.json)?$", "")
                .replaceAll("[^A-Za-z0-9]+", "-")
                .replaceAll("^-+|-+$", "");
        if (safe.isEmpty()) {
            safe = "voz";
        }
        final String key = code + "-" + safe;

        final File voices = PiperVoiceStore.voicesDir(storage);
        voices.mkdirs();
        final File dest = new File(voices, key);
        if (dest.exists()) {
            return null;
        }
        final File tmp = new File(voices, ".tmp-" + key);
        deleteRecursive(tmp);
        if (!tmp.mkdirs()) {
            throw new IOException("sem espaco ou permissao para instalar");
        }
        try {
            final File modelFile = new File(tmp, PiperVoiceStore.MODEL_FILE);
            try (OutputStream out = new FileOutputStream(modelFile)) {
                final byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = model.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
            }
            if (modelFile.length() < 100 * 1024) {
                throw new IOException("arquivo .onnx pequeno demais");
            }
            try (OutputStream out = new FileOutputStream(new File(tmp, PiperVoiceStore.CONFIG_FILE))) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
            }
            if (!tmp.renameTo(dest)) {
                throw new IOException("nao foi possivel concluir a instalacao");
            }
        } catch (IOException e) {
            deleteRecursive(tmp);
            throw e;
        }
        PiperVoiceStore.invalidate();
        // Como as vozes baixadas: se o idioma ainda nao tem voz neural escolhida, esta passa a ser a dele.
        String assigned = null;
        final PiperVoiceStore.Installed installed = PiperVoiceStore.find(storage, key);
        if (installed != null) {
            final String lang = installed.languageKey();
            final android.content.SharedPreferences settings =
                    androidx.preference.PreferenceManager.getDefaultSharedPreferences(storage);
            if (PiperVoiceStore.assignedKey(settings, lang) == null) {
                PiperVoiceStore.assign(settings, lang, key);
                assigned = lang;
            }
        }
        PiperDownloads.broadcastChanged(storage, key, assigned);
        return key;
    }

    private static byte[] readAll(InputStream in, int max) throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            if (out.size() > max) {
                throw new IOException("arquivo .json grande demais");
            }
        }
        return out.toByteArray();
    }

    private static void deleteRecursive(File f) {
        final File[] children = f.listFiles();
        if (children != null) {
            for (File c : children) {
                deleteRecursive(c);
            }
        }
        f.delete();
    }
}
