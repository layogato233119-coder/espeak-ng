/*
 * Diferente dos Normais / Android Todo Tempo.
 * Instala sozinho as vozes neurais que vem dentro do APK (assets/vozes-incluidas/<nome>/
 * model.onnx + model.onnx.json). A cada atualizacao do app, as vozes novas aparecem
 * prontas para escolher, sem baixar nem importar nada. GPL v3 ou posterior.
 */

package com.animeshahilya.espeakng;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.util.Log;

import androidx.preference.PreferenceManager;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

final class BundledVoices {
    private static final String TAG = "BundledVoices";
    static final String ASSET_DIR = "vozes-incluidas";
    private static final String PREF_ENABLED_ONCE = "bundled_voices_enabled_once";

    private BundledVoices() {
    }

    /** Em segundo plano, a cada inicio do processo. Voz ja instalada e pulada sem ler o modelo. */
    static void installAsync(final Context app) {
        new Thread(() -> {
            try {
                installAll(app);
            } catch (Throwable t) {
                Log.w(TAG, "Falha ao instalar as vozes incluidas", t);
            }
        }, "bundled-voices").start();
    }

    private static void installAll(Context app) throws IOException {
        final AssetManager assets = app.getAssets();
        final String[] names = assets.list(ASSET_DIR);
        if (names == null || names.length == 0) {
            return;
        }
        final Context storage = EspeakApp.requireStorageContext(app);
        int installed = 0;
        for (String name : names) {
            final String dir = ASSET_DIR + "/" + name;
            final String[] files = assets.list(dir);
            if (files == null) {
                continue;
            }
            final List<String> list = Arrays.asList(files);
            if (!list.contains(PiperVoiceStore.MODEL_FILE) || !list.contains(PiperVoiceStore.CONFIG_FILE)) {
                Log.w(TAG, "Pasta de voz incompleta: " + name);
                continue;
            }
            try (InputStream model = assets.open(dir + "/" + PiperVoiceStore.MODEL_FILE);
                 InputStream config = assets.open(dir + "/" + PiperVoiceStore.CONFIG_FILE)) {
                if (CustomVoiceImporter.install(storage, name, model, config) != null) {
                    installed++;
                }
            } catch (IOException e) {
                Log.w(TAG, "Nao foi possivel instalar " + name + ": " + e.getMessage());
            }
        }
        if (installed > 0) {
            // As vozes neurais ficam desligadas por padrao; com vozes incluidas, o usuario
            // espera so escolher e usar. Liga uma unica vez; depois a escolha dele vale.
            final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(storage);
            if (!prefs.getBoolean(PREF_ENABLED_ONCE, false)) {
                prefs.edit()
                        .putBoolean(PiperVoiceStore.PREF_ENABLED, true)
                        .putBoolean(PREF_ENABLED_ONCE, true)
                        .apply();
            }
        }
    }
}
