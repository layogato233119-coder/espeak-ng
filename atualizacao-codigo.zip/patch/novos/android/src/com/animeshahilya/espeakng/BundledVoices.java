/*
 * Diferente dos Normais / Android Todo Tempo.
 * Instala sozinho as vozes neurais que vem dentro do APK (assets/vozes-incluidas/<nome>/
 * model.onnx + model.onnx.json), escolhe a voz para o idioma dela (uma unica vez, depois a
 * escolha do usuario vale) e AVISA na tela se deu certo ou por que falhou. GPL v3 ou posterior.
 */

package com.animeshahilya.espeakng;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.preference.PreferenceManager;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class BundledVoices {
    private static final String TAG = "BundledVoices";
    static final String ASSET_DIR = "vozes-incluidas";
    private static final String PREF_ENABLED_ONCE = "bundled_voices_enabled_once";
    private static final String PREF_ASSIGNED_PREFIX = "bundled_voice_assigned_";

    private BundledVoices() {
    }

    /** Em segundo plano, a cada inicio do processo. Voz ja instalada e pulada sem ler o modelo. */
    static void installAsync(final Context app) {
        new Thread(() -> {
            try {
                installAll(app);
            } catch (Throwable t) {
                Log.w(TAG, "Falha ao instalar as vozes incluidas", t);
                toast(app, "Falha ao instalar a voz Miro: " + t);
            }
        }, "bundled-voices").start();
    }

    private static void toast(final Context app, final String text) {
        new Handler(Looper.getMainLooper()).post(
                () -> Toast.makeText(app, text, Toast.LENGTH_LONG).show());
    }

    private static String safeName(String name) {
        String safe = name.replaceAll("(?i)\\.onnx(\\.json)?$", "")
                .replaceAll("[^A-Za-z0-9]+", "-")
                .replaceAll("^-+|-+$", "");
        return safe.isEmpty() ? "voz" : safe;
    }

    private static String findKey(Context storage, String name) {
        final String suffix = "-" + safeName(name);
        for (PiperVoiceStore.Installed v : PiperVoiceStore.list(storage)) {
            if (v.key.endsWith(suffix)) {
                return v.key;
            }
        }
        return null;
    }

    /**
     * Se o modelo que vem no APK mudou (tamanho diferente do instalado), apaga a copia antiga para
     * a nova ser instalada. Assim uma versao corrigida da voz entra por cima, sem desinstalar o app.
     */
    private static boolean replaceIfDifferent(AssetManager assets, Context storage, String dir, String name) {
        try {
            final String key = findKey(storage, name);
            if (key == null) {
                return false;
            }
            final long inApk;
            try (android.content.res.AssetFileDescriptor fd =
                         assets.openFd(dir + "/" + PiperVoiceStore.MODEL_FILE)) {
                inApk = fd.getLength();
            }
            final java.io.File voiceDir = new java.io.File(PiperVoiceStore.voicesDir(storage), key);
            final java.io.File installed = new java.io.File(voiceDir, PiperVoiceStore.MODEL_FILE);
            if (inApk > 0 && installed.length() != inApk) {
                Log.i(TAG, "Voz " + key + " mudou no APK; reinstalando");
                PiperDownloads.deleteRecursively(voiceDir);
                PiperVoiceStore.invalidate();
                return true;
            }
        } catch (Throwable t) {
            Log.w(TAG, "Nao foi possivel conferir a voz incluida " + name, t);
        }
        return false;
    }

    private static void installAll(Context app) throws IOException {
        final AssetManager assets = app.getAssets();
        final String[] names = assets.list(ASSET_DIR);
        if (names == null || names.length == 0) {
            return;
        }
        final Context storage = EspeakApp.requireStorageContext(app);
        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(storage);
        final List<String> problems = new ArrayList<>();
        boolean anyPresent = false;
        for (String name : names) {
            final String dir = ASSET_DIR + "/" + name;
            final String[] files = assets.list(dir);
            if (files == null) {
                continue;
            }
            final List<String> list = Arrays.asList(files);
            if (!list.contains(PiperVoiceStore.MODEL_FILE) || !list.contains(PiperVoiceStore.CONFIG_FILE)) {
                Log.w(TAG, "Pasta de voz incompleta: " + name);
                problems.add(name + ": arquivos incompletos no app");
                continue;
            }
            final boolean replaced = replaceIfDifferent(assets, storage, dir, name);
            try (InputStream model = assets.open(dir + "/" + PiperVoiceStore.MODEL_FILE);
                 InputStream config = assets.open(dir + "/" + PiperVoiceStore.CONFIG_FILE)) {
                CustomVoiceImporter.install(storage, name, model, config);
            } catch (IOException e) {
                Log.w(TAG, "Nao foi possivel instalar " + name + ": " + e.getMessage());
                problems.add(name + ": " + e.getMessage());
                continue;
            }
            PiperVoiceStore.invalidate();
            final String key = findKey(storage, name);
            if (key == null) {
                problems.add(name + ": o app nao reconheceu a voz depois de instalar");
                continue;
            }
            anyPresent = true;
            if (replaced) {
                toast(app, "Voz " + name.replaceAll("-.*$", "") + " atualizada.");
            }
            // Uma unica vez por voz: se o idioma ainda nao tem voz neural escolhida, esta passa a ser
            // a dele. Depois disso, a escolha do usuario (inclusive voltar ao eSpeak) vale.
            if (!prefs.getBoolean(PREF_ASSIGNED_PREFIX + key, false)) {
                final PiperVoiceStore.Installed voice = PiperVoiceStore.find(storage, key);
                String assigned = null;
                if (voice != null) {
                    final String lang = voice.languageKey();
                    if (PiperVoiceStore.assignedKey(prefs, lang) == null) {
                        PiperVoiceStore.assign(prefs, lang, key);
                        assigned = lang;
                    }
                }
                prefs.edit().putBoolean(PREF_ASSIGNED_PREFIX + key, true).apply();
                PiperDownloads.broadcastChanged(storage, key, assigned);
                toast(app, "Voz " + name.replaceAll("-.*$", "") + " instalada e escolhida para o idioma dela.");
            }
        }
        if (anyPresent && !prefs.getBoolean(PREF_ENABLED_ONCE, false)) {
            // As vozes neurais ficam desligadas por padrao; com vozes incluidas, o usuario
            // espera so escolher e usar. Liga uma unica vez; depois a escolha dele vale.
            prefs.edit()
                    .putBoolean(PiperVoiceStore.PREF_ENABLED, true)
                    .putBoolean(PREF_ENABLED_ONCE, true)
                    .apply();
        }
        if (!problems.isEmpty()) {
            toast(app, "Problema com a voz incluida: " + problems.get(0));
        }
    }
}
