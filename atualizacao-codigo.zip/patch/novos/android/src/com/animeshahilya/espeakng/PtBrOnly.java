/*
 * Diferente dos Normais / Android Todo Tempo.
 * A lista de vozes neurais para baixar mostra somente vozes do portugues do Brasil (pt_BR).
 * Para voltar a mostrar todos os idiomas, troque SOMENTE_PT_BR por false. GPL v3 ou posterior.
 */

package com.animeshahilya.espeakng;

import java.util.ArrayList;
import java.util.List;

final class PtBrOnly {
    static final boolean SOMENTE_PT_BR = true;

    private PtBrOnly() {
    }

    static List<PiperDownloads.CatalogVoice> filter(List<PiperDownloads.CatalogVoice> all) {
        if (all == null || !SOMENTE_PT_BR) {
            return all;
        }
        final List<PiperDownloads.CatalogVoice> out = new ArrayList<>();
        for (PiperDownloads.CatalogVoice v : all) {
            if ("pt_BR".equals(v.code)) {
                out.add(v);
            }
        }
        return out;
    }
}
