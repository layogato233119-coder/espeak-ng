/*
 * Diferente dos Normais / Android Todo Tempo.
 * Tela "Dicionarios importados": lista todos os dicionarios importados, um ao lado do outro.
 * Toque: ativa ou desativa. Toque e segure: excluir (com confirmacao) ou renomear.
 * GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import androidx.core.content.FileProvider;

public class DictionaryPacksActivity extends AppCompatActivity {
    private DictionaryPacks packs;
    private final List<DictionaryPacks.Pack> current = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private final Set<String> selected = new HashSet<>();
    private Button shareButton;
    private Button deleteButton;
    private TextView empty;
    private ListView list;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ActivityResultLauncher<String[]> picker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.packs_title);
        packs = DictionaryPacks.get(this);
        picker = registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPicked);

        final int pad = dp(16);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        final TextView title = new TextView(this);
        title.setText(R.string.packs_title);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        ViewCompat.setAccessibilityHeading(title, true);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final TextView hint = new TextView(this);
        hint.setText(R.string.packs_hint);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        hint.setPadding(0, dp(8), 0, dp(8));
        root.addView(hint, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final Button importButton = new Button(this);
        importButton.setText(R.string.packs_import);
        importButton.setOnClickListener(v -> picker.launch(new String[]{"*/*"}));
        root.addView(importButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        shareButton = new Button(this);
        shareButton.setText(R.string.packs_share);
        shareButton.setOnClickListener(v -> shareSelected());
        shareButton.setVisibility(View.GONE);
        root.addView(shareButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        deleteButton = new Button(this);
        deleteButton.setText(R.string.packs_delete_selected);
        deleteButton.setOnClickListener(v -> confirmDeleteSelected());
        deleteButton.setVisibility(View.GONE);
        root.addView(deleteButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        empty = new TextView(this);
        empty.setText(R.string.packs_empty);
        empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        empty.setPadding(0, dp(16), 0, dp(16));
        root.addView(empty, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice,
                new ArrayList<String>());
        list = new ListView(this);
        list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> onRowTapped(position));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            showOptions(position);
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        ViewCompat.setOnApplyWindowInsetsListener(root, (View v, WindowInsetsCompat insets) -> {
            final Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left + pad, bars.top + pad, bars.right + pad, bars.bottom + pad);
            return insets;
        });
        setContentView(root);
        refresh();
    }

    private void refresh() {
        current.clear();
        current.addAll(packs.list());
        adapter.clear();
        for (DictionaryPacks.Pack p : current) {
            adapter.add(getString(R.string.packs_row, p.name, p.count,
                    getString(p.active ? R.string.packs_on : R.string.packs_off)));
        }
        adapter.notifyDataSetChanged();
        final Set<String> alive = new HashSet<>();
        for (int i = 0; i < current.size(); i++) {
            final String id = current.get(i).id;
            alive.add(id);
            list.setItemChecked(i, selected.contains(id));
        }
        selected.retainAll(alive);
        updateButtons();
        empty.setVisibility(current.isEmpty() ? View.VISIBLE : View.GONE);
        list.setVisibility(current.isEmpty() ? View.GONE : View.VISIBLE);
    }

    /** Toque: marca ou desmarca o dicionário. Quantos quiser, sem limite. */
    private void onRowTapped(int position) {
        if (position < 0 || position >= current.size()) {
            return;
        }
        final String id = current.get(position).id;
        if (list.isItemChecked(position)) {
            selected.add(id);
        } else {
            selected.remove(id);
        }
        updateButtons();
    }

    /** Compartilhar aparece com 1 ou mais marcados; Excluir só com 2 ou mais (com 1, use toque e segure). */
    private void updateButtons() {
        final int n = selected.size();
        shareButton.setVisibility(n >= 1 ? View.VISIBLE : View.GONE);
        deleteButton.setVisibility(n >= 2 ? View.VISIBLE : View.GONE);
        shareButton.setText(getResources().getQuantityString(R.plurals.packs_share_n, n, n));
        deleteButton.setText(getResources().getQuantityString(R.plurals.packs_delete_n, n, n));
    }

    private List<DictionaryPacks.Pack> selectedPacks() {
        final List<DictionaryPacks.Pack> out = new ArrayList<>();
        for (DictionaryPacks.Pack p : current) {
            if (selected.contains(p.id)) {
                out.add(p);
            }
        }
        return out;
    }

    private void shareSelected() {
        final List<DictionaryPacks.Pack> chosen = selectedPacks();
        if (chosen.isEmpty()) {
            return;
        }
        try {
            final File dir = new File(getCacheDir(), "dn_share");
            dir.mkdirs();
            final File[] old = dir.listFiles();
            if (old != null) {
                for (File f : old) {
                    f.delete();
                }
            }
            final ArrayList<Uri> uris = new ArrayList<>();
            for (DictionaryPacks.Pack p : chosen) {
                final File src = packs.fileOf(p.id);
                if (src == null) {
                    continue;
                }
                String safe = p.name.replaceAll("[\\/:*?\"<>|]+", "-").trim();
                if (safe.isEmpty()) {
                    safe = "dicionario";
                }
                File dest = new File(dir, safe + ".txt");
                int n = 2;
                while (dest.exists()) {
                    dest = new File(dir, safe + " (" + n++ + ").txt");
                }
                try (InputStream in = new FileInputStream(src);
                     OutputStream out = new FileOutputStream(dest)) {
                    final byte[] buf = new byte[16 * 1024];
                    int r;
                    while ((r = in.read(buf)) > 0) {
                        out.write(buf, 0, r);
                    }
                }
                uris.add(FileProvider.getUriForFile(this, getPackageName() + ".dnshare", dest));
            }
            if (uris.isEmpty()) {
                Toast.makeText(this, R.string.packs_share_failed, Toast.LENGTH_LONG).show();
                return;
            }
            final Intent send = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
            send.setType("text/plain");
            if (uris.size() == 1) {
                send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            } else {
                send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            }
            send.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.packs_share_subject));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, getString(R.string.packs_share_title)));
        } catch (IOException | RuntimeException e) {
            Toast.makeText(this, R.string.packs_share_failed, Toast.LENGTH_LONG).show();
        }
    }

    /** Sim ou Não, depois OK ou Cancelar. O padrão é Não. */
    private void confirmDeleteSelected() {
        final List<DictionaryPacks.Pack> chosen = selectedPacks();
        if (chosen.isEmpty()) {
            return;
        }
        final int[] choice = {1};
        new AlertDialog.Builder(this)
                .setTitle(getResources().getQuantityString(R.plurals.packs_confirm_many, chosen.size(), chosen.size()))
                .setSingleChoiceItems(new CharSequence[]{getString(R.string.packs_yes), getString(R.string.packs_no)},
                        1, (d, which) -> choice[0] = which)
                .setPositiveButton(R.string.packs_ok, (d, w) -> {
                    if (choice[0] == 0) {
                        for (DictionaryPacks.Pack p : chosen) {
                            packs.delete(p.id);
                            selected.remove(p.id);
                        }
                        refresh();
                        Toast.makeText(this, R.string.packs_deleted, Toast.LENGTH_SHORT).show();
                        list.announceForAccessibility(getString(R.string.packs_deleted));
                    }
                })
                .setNegativeButton(R.string.packs_cancel, null)
                .show();
    }

    private void toggle(int position) {
        if (position < 0 || position >= current.size()) {
            return;
        }
        final DictionaryPacks.Pack p = current.get(position);
        packs.setActive(p.id, !p.active);
        refresh();
        final String msg = p.name + ". " + getString(p.active ? R.string.packs_off : R.string.packs_on);
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        list.announceForAccessibility(msg);
    }

    private void showOptions(int position) {
        if (position < 0 || position >= current.size()) {
            return;
        }
        final DictionaryPacks.Pack p = current.get(position);
        final CharSequence[] items = {
                getString(p.active ? R.string.packs_deactivate : R.string.packs_activate),
                getString(R.string.packs_delete), getString(R.string.packs_rename)};
        new AlertDialog.Builder(this)
                .setTitle(p.name)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        toggle(position);
                    } else if (which == 1) {
                        confirmDelete(p);
                    } else {
                        askRename(p);
                    }
                })
                .setNegativeButton(R.string.packs_cancel, null)
                .show();
    }

    /** Sim ou Não, depois OK ou Cancelar. O padrão é Não, para não excluir sem querer. */
    private void confirmDelete(final DictionaryPacks.Pack p) {
        final int[] choice = {1};
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.packs_confirm_title, p.name))
                .setSingleChoiceItems(new CharSequence[]{getString(R.string.packs_yes), getString(R.string.packs_no)},
                        1, (d, which) -> choice[0] = which)
                .setPositiveButton(R.string.packs_ok, (d, w) -> {
                    if (choice[0] == 0) {
                        packs.delete(p.id);
                        selected.remove(p.id);
                        refresh();
                        Toast.makeText(this, R.string.packs_deleted, Toast.LENGTH_SHORT).show();
                        list.announceForAccessibility(getString(R.string.packs_deleted));
                    }
                })
                .setNegativeButton(R.string.packs_cancel, null)
                .show();
    }

    private void askRename(final DictionaryPacks.Pack p) {
        final EditText input = new EditText(this);
        input.setText(p.name);
        input.setSelection(p.name.length());
        new AlertDialog.Builder(this)
                .setTitle(R.string.packs_rename_title)
                .setView(input)
                .setPositiveButton(R.string.packs_ok, (d, w) -> {
                    packs.rename(p.id, input.getText().toString());
                    refresh();
                })
                .setNegativeButton(R.string.packs_cancel, null)
                .show();
    }

    private void onPicked(List<Uri> uris) {
        if (uris == null || uris.isEmpty()) {
            return;
        }
        Toast.makeText(this, R.string.packs_importing, Toast.LENGTH_SHORT).show();
        final List<Uri> files = new ArrayList<>(uris);
        final android.content.Context app = getApplicationContext();
        new Thread(() -> {
            int dictionaries = 0;
            int rules = 0;
            final StringBuilder failed = new StringBuilder();
            for (Uri uri : files) {
                try {
                    final DictionaryPacks.ImportResult r = DictionaryPacks.importUri(app, uri);
                    if (r.dictionaries > 0) {
                        dictionaries += r.dictionaries;
                        rules += r.rules;
                    } else {
                        failed.append(failed.length() > 0 ? ", " : "")
                                .append(DictionaryFormats.displayName(app, uri));
                    }
                } catch (Exception e) {
                    failed.append(failed.length() > 0 ? ", " : "")
                            .append(DictionaryFormats.displayName(app, uri));
                }
            }
            final int totalDicts = dictionaries;
            final int totalRules = rules;
            final String bad = failed.toString();
            main.post(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                refresh();
                final StringBuilder msg = new StringBuilder();
                if (totalDicts == 1) {
                    msg.append(getString(R.string.packs_done_one, totalRules));
                } else if (totalDicts > 1) {
                    msg.append(getString(R.string.packs_done_many, totalDicts, totalRules));
                }
                if (!bad.isEmpty()) {
                    msg.append(msg.length() > 0 ? " " : "").append(getString(R.string.packs_none, bad));
                }
                Toast.makeText(this, msg.toString(), Toast.LENGTH_LONG).show();
                list.announceForAccessibility(msg.toString());
            });
        }, "dict-packs-import").start();
    }

    private int dp(int value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()));
    }
}
