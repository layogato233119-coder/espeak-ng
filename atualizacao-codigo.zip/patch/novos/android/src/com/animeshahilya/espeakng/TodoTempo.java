/*
 * Diferente dos Normais / Android Todo Tempo.
 * Linhas extras das configuracoes: menu da comunidade, vozes do sistema e tutorial.
 * GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.preference.Preference;
import androidx.preference.PreferenceScreen;

final class TodoTempo {
    private TodoTempo() {
    }

    /** Liga as linhas de preferencia adicionadas por patch/aplicar.py. */
    static void wire(final Context context, final PreferenceScreen screen) {
        click(screen, "action_todo_tempo_menu", () -> showMenu(context));
        click(screen, "action_system_voices", () -> openSystemVoices(context));
        click(screen, "action_welcome", () -> startWelcome(context));
        click(screen, "action_dictionary_packs", () -> startDictionaryPacks(context));
    }

    private static void click(PreferenceScreen screen, String key, Runnable action) {
        final Preference p = screen.findPreference(key);
        if (p != null) {
            p.setOnPreferenceClickListener(pref -> {
                action.run();
                return true;
            });
        }
    }

    private static void startDictionaryPacks(Context context) {
        final Intent i = new Intent(context, DictionaryPacksActivity.class);
        if (!(context instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(i);
    }

    private static void startWelcome(Context context) {
        final Intent i = new Intent(context, WelcomeActivity.class).putExtra(WelcomeActivity.EXTRA_REVIEW, true);
        if (!(context instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(i);
    }

    private static void showMenu(final Context context) {
        final CharSequence[] items = {
                context.getString(R.string.menu_youtube),
                context.getString(R.string.menu_whatsapp),
                context.getString(R.string.menu_telegram),
                context.getString(R.string.menu_welcome),
        };
        new AlertDialog.Builder(context)
                .setTitle(R.string.todo_category)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            open(context, context.getString(R.string.link_youtube));
                            break;
                        case 1:
                            open(context, context.getString(R.string.link_whatsapp));
                            break;
                        case 2:
                            open(context, context.getString(R.string.link_telegram));
                            break;
                        default:
                            startWelcome(context);
                            break;
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void open(Context context, String url) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(context, R.string.link_missing, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            final Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url.trim()));
            if (!(context instanceof Activity)) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, R.string.link_missing, Toast.LENGTH_LONG).show();
        }
    }

    private static void openSystemVoices(Context context) {
        final Intent tts = new Intent("com.android.settings.TTS_SETTINGS");
        if (!(context instanceof Activity)) {
            tts.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        try {
            context.startActivity(tts);
        } catch (ActivityNotFoundException e) {
            final Intent general = new Intent(Settings.ACTION_SETTINGS);
            if (!(context instanceof Activity)) {
                general.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(general);
        }
    }
}
