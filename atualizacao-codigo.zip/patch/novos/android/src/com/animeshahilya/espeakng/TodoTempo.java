/*
 * Diferente dos Normais / Android Todo Tempo.
 * Linhas extras das configuracoes: menu da comunidade, vozes do sistema e tutorial.
 * GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceScreen;

final class TodoTempo {
    private TodoTempo() {
    }

    /** Liga as linhas de preferencia adicionadas por patch/aplicar.py. */
    static void wire(final Context context, final PreferenceScreen screen) {
        click(screen, "action_todo_tempo_menu", () -> showMenu(context));
        click(screen, "action_system_voices", () -> openSystemVoices(context));
        click(screen, "action_welcome", () -> startWelcome(context));
        click(screen, "action_dictionary_packs", () -> startDictionaryPacks(context));
    }

    private static final String FLOAT_TAG = "dn_menu_flutuante";

    /**
     * Botao sempre visivel no canto inferior direito, em todas as telas da
     * configuracao: abre o menu das redes sociais (Laionil TTS, Android Todo Tempo).
     */
    static void attachFloating(final Activity activity) {
        activity.getWindow().getDecorView().post(() -> {
            final ViewGroup content = activity.findViewById(android.R.id.content);
            if (content == null || content.findViewWithTag(FLOAT_TAG) != null) {
                return;
            }
            final Button b = new Button(activity);
            b.setTag(FLOAT_TAG);
            b.setText(R.string.todo_float_label);
            b.setAllCaps(false);
            b.setContentDescription(activity.getString(R.string.todo_float_desc));
            b.setElevation(dp(activity, 8));
            b.setOnClickListener(v -> showMenu(activity));
            final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.END);
            lp.setMargins(0, 0, dp(activity, 16), dp(activity, 16));
            content.addView(b, lp);
            ViewCompat.setOnApplyWindowInsetsListener(b, (View v, WindowInsetsCompat insets) -> {
                final Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                final FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) v.getLayoutParams();
                p.setMargins(0, 0, dp(activity, 16) + bars.right, dp(activity, 16) + bars.bottom);
                v.setLayoutParams(p);
                return insets;
            });
            ViewCompat.requestApplyInsets(b);
            // So na tela principal: nas telas de dentro o botao some (e sai da navegacao do leitor de tela).
            b.setVisibility(View.GONE);
            final Object[] last = new Object[2];
            content.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
                final boolean main = isMainScreen(activity, last);
                final int want = main ? View.VISIBLE : View.GONE;
                if (b.getVisibility() != want) {
                    b.setVisibility(want);
                }
            });
        });
    }

    private static boolean isMainScreen(Activity activity, Object[] last) {
        if (!(activity instanceof androidx.fragment.app.FragmentActivity)) {
            return false;
        }
        final androidx.fragment.app.Fragment f = ((androidx.fragment.app.FragmentActivity) activity)
                .getSupportFragmentManager().findFragmentById(android.R.id.content);
        if (!(f instanceof PreferenceFragmentCompat)) {
            return false;
        }
        final PreferenceScreen ps = ((PreferenceFragmentCompat) f).getPreferenceScreen();
        if (ps == null) {
            return false;
        }
        if (last[0] == ps) {
            return Boolean.TRUE.equals(last[1]);
        }
        final boolean main = ps.findPreference("action_todo_tempo_menu") != null;
        last[0] = ps;
        last[1] = main;
        return main;
    }

    private static int dp(Context context, int value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics()));
    }

    private static void click(PreferenceScreen screen, String key, Runnable action) {
        final Preference p = screen.findPreference(key);
        if (p != null) {
            p.setOnPreferenceClickListener(pref -> {
                action.run();
                return true;
            });
        }
    }

    private static void startDictionaryPacks(Context context) {
        final Intent i = new Intent(context, DictionaryPacksActivity.class);
        if (!(context instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(i);
    }

    private static void startWelcome(Context context) {
        final Intent i = new Intent(context, WelcomeActivity.class).putExtra(WelcomeActivity.EXTRA_REVIEW, true);
        if (!(context instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(i);
    }

    private static void showMenu(final Context context) {
        final CharSequence[] items = {
                context.getString(R.string.menu_youtube),
                context.getString(R.string.menu_whatsapp),
                context.getString(R.string.menu_telegram),
                context.getString(R.string.menu_welcome),
        };
        new AlertDialog.Builder(context)
                .setTitle(R.string.todo_social_title)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            open(context, context.getString(R.string.link_youtube));
                            break;
                        case 1:
                            open(context, context.getString(R.string.link_whatsapp));
                            break;
                        case 2:
                            open(context, context.getString(R.string.link_telegram));
                            break;
                        default:
                            startWelcome(context);
                            break;
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void open(Context context, String url) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(context, R.string.link_missing, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            final Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url.trim()));
            if (!(context instanceof Activity)) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, R.string.link_missing, Toast.LENGTH_LONG).show();
        }
    }

    private static void openSystemVoices(Context context) {
        final Intent tts = new Intent("com.android.settings.TTS_SETTINGS");
        if (!(context instanceof Activity)) {
            tts.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        try {
            context.startActivity(tts);
        } catch (ActivityNotFoundException e) {
            final Intent general = new Intent(Settings.ACTION_SETTINGS);
            if (!(context instanceof Activity)) {
                general.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(general);
        }
    }
}
