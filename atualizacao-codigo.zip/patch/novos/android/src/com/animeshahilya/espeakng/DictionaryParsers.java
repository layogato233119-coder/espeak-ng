/*
 * Diferente dos Normais / Android Todo Tempo.
 * Leitores de dicionarios de texto puro (sem dependencia do Android, para poder testar):
 *  - CFD / BIN do Eloquence e Vocalizer: cada linha comeca com o separador usado nela
 *    (".palavra.pronuncia.*.*.*.0.0." ou ",palavra,pronuncia,*,*,*,0,0,"), em UTF-16
 *  - dict.txt da RH Voice: palavra=pronuncia, trechos (x=y) e alternativas {,s}
 *  - replaces.yaml do Multi TTS (ReplaceConfig)
 * GPL v3 ou posterior, como o projeto.
 */

package com.animeshahilya.espeakng;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class DictionaryParsers {
    /** Uma regra lida: tipo "0" = em qualquer lugar, "1" = regex, "2" = palavra inteira. */
    static final class Row {
        final String pattern;
        final String replacement;
        final String category;
        final String type;

        Row(String pattern, String replacement, String category, String type) {
            this.pattern = pattern;
            this.replacement = replacement;
            this.category = category;
            this.type = type;
        }
    }

    // separador + palavra + separador + pronuncia + separador *,*,* + dois numeros
    private static final Pattern CFD_LINE = Pattern.compile(
            "^([^\\p{L}\\p{N}\\s])(.+)\\1\\*\\1\\*\\1\\*\\1\\d+\\1\\d+\\1\\s*$");
    private static final Pattern GROUP = Pattern.compile("\\(([^()=]*)=([^()]*)\\)");
    private static final Pattern BRACES = Pattern.compile("\\{([^{}]*)\\}");
    private static final Pattern HEX_ESCAPE = Pattern.compile("\\\\(?:x([0-9A-Fa-f]{2})|u([0-9A-Fa-f]{4}))");

    private DictionaryParsers() {
    }

    /**
     * Devolve as regras se o texto for de um destes formatos; null se nao for
     * (o chamador tenta os outros leitores).
     */
    static List<Row> parse(String text) {
        if (text == null) {
            return null;
        }
        String t = text.replace("\u0000", "");
        if (t.startsWith("\uFEFF")) {
            t = t.substring(1);
        }
        final String trimmed = t.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.contains("ReplaceConfig") || trimmed.startsWith("- activate:")
                || trimmed.contains("\n- activate:")) {
            return parseYaml(t);
        }
        final String[] lines = t.split("\r\n|\n|\r");
        int total = 0;
        int cfd = 0;
        for (String l : lines) {
            final String s = l.trim();
            if (s.isEmpty()) {
                continue;
            }
            total++;
            if (CFD_LINE.matcher(s).matches()) {
                cfd++;
            }
        }
        if (total > 0 && cfd * 2 >= total) {
            return parseCfd(lines);
        }
        final char first = trimmed.charAt(0);
        if (first == '{' || first == '[' || first == '<') {
            return null;
        }
        return parseEqualsLines(lines);
    }

    // ---- CFD / BIN ---------------------------------------------------------------------

    private static List<Row> parseCfd(String[] lines) {
        final List<Row> rows = new ArrayList<>();
        for (String raw : lines) {
            final String line = raw.trim();
            final Matcher m = CFD_LINE.matcher(line);
            if (!m.matches()) {
                continue;
            }
            final String d = m.group(1);
            final String body = m.group(2);
            final int cut = body.indexOf(d);
            if (cut < 0) {
                continue;
            }
            final String word = unescape(body.substring(0, cut)).trim();
            final String repl = unescape(body.substring(cut + d.length())).trim();
            // resposta vazia = o leitor de tela nao fala aquela frase (valido)
            if (word.isEmpty() || word.equals(repl)) {
                continue;
            }
            if (isGarbage(word) || isGarbage(repl)) {
                continue;
            }
            rows.add(new Row(word, repl, "main", typeFor(word)));
        }
        return rows;
    }

    private static boolean isGarbage(String s) {
        return s.indexOf('\uFFFD') >= 0 || s.toLowerCase(Locale.ROOT).contains("<lang")
                || s.toLowerCase(Locale.ROOT).contains("realspeak");
    }

    // ---- RH Voice (dict.txt) e listas palavra=pronuncia -----------------------------------

    private static List<Row> parseEqualsLines(String[] lines) {
        final List<Row> rows = new ArrayList<>();
        boolean any = false;
        for (String raw : lines) {
            final String line = raw.trim();
            if (line.isEmpty() || line.startsWith(";") || line.startsWith("#") || line.startsWith("//")) {
                continue;
            }
            final boolean hasGroup = GROUP.matcher(line).find();
            final String outside = GROUP.matcher(line).replaceAll("");
            final boolean topEquals = outside.indexOf('=') > 0;
            if (!hasGroup && !topEquals) {
                continue;
            }
            any = true;
            for (String variant : expandBraces(line)) {
                final String p;
                final String r;
                if (hasGroup && !topEquals) {
                    p = GROUP.matcher(variant).replaceAll("$1");
                    r = replaceGroups(variant);
                } else {
                    final int eq = GROUP.matcher(variant).replaceAll("").indexOf('=');
                    if (eq <= 0) {
                        continue;
                    }
                    final String plain = variant;
                    final int idx = plain.indexOf('=');
                    p = plain.substring(0, idx);
                    r = plain.substring(idx + 1);
                }
                final String pp = unescape(p).trim();
                final String rr = unescape(r).trim();
                if (!pp.isEmpty() && !rr.isEmpty() && !pp.equals(rr)) {
                    rows.add(new Row(pp, rr, "main", typeFor(pp)));
                }
            }
        }
        return any ? rows : null;
    }

    private static String replaceGroups(String s) {
        final Matcher m = GROUP.matcher(s);
        final StringBuffer out = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(out, Matcher.quoteReplacement(m.group(2)));
        }
        m.appendTail(out);
        return out.toString();
    }

    /** "casa{,s}" vira "casa" e "casas"; no maximo 16 variantes. */
    static List<String> expandBraces(String s) {
        List<String> current = new ArrayList<>();
        current.add(s);
        for (int guard = 0; guard < 4; guard++) {
            final List<String> next = new ArrayList<>();
            boolean changed = false;
            for (String item : current) {
                final Matcher m = BRACES.matcher(item);
                if (!m.find()) {
                    next.add(item);
                    continue;
                }
                changed = true;
                final String[] options = m.group(1).split(",", -1);
                for (String option : options) {
                    if (next.size() >= 16) {
                        break;
                    }
                    next.add(item.substring(0, m.start()) + option + item.substring(m.end()));
                }
            }
            current = next;
            if (!changed) {
                break;
            }
        }
        return current;
    }

    // ---- Multi TTS (replaces.yaml) ---------------------------------------------------------

    private static List<Row> parseYaml(String text) {
        final List<Row> rows = new ArrayList<>();
        String source = null;
        String target = null;
        boolean active = true;
        boolean regex = false;
        boolean open = false;
        for (String raw : text.split("\r\n|\n|\r")) {
            String line = raw;
            final boolean newItem = line.startsWith("- ") || line.trim().startsWith("- activate:");
            if (newItem) {
                if (open) {
                    addYaml(rows, source, target, active, regex);
                }
                source = null;
                target = null;
                active = true;
                regex = false;
                open = true;
                line = line.trim().substring(2);
            }
            final String l = line.trim();
            final int colon = l.indexOf(':');
            if (colon <= 0 || !open) {
                continue;
            }
            final String key = l.substring(0, colon).trim();
            final String value = yamlValue(l.substring(colon + 1));
            switch (key) {
                case "activate":
                    active = !"false".equalsIgnoreCase(value);
                    break;
                case "regex":
                    regex = "true".equalsIgnoreCase(value);
                    break;
                case "source":
                    source = value;
                    break;
                case "target":
                    target = value;
                    break;
                default:
                    break;
            }
        }
        if (open) {
            addYaml(rows, source, target, active, regex);
        }
        return rows;
    }

    private static void addYaml(List<Row> rows, String source, String target, boolean active, boolean regex) {
        if (!active || source == null || source.isEmpty() || target == null || target.isEmpty()) {
            return;
        }
        if (!regex && source.equals(target)) {
            return;
        }
        rows.add(new Row(source, target, "main", regex ? "1" : typeFor(source)));
    }

    private static String yamlValue(String v) {
        String s = v.trim();
        if (s.length() >= 2 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) {
            final char q = s.charAt(0);
            s = s.substring(1, s.length() - 1);
            if (q == '\'') {
                s = s.replace("''", "'");
            } else {
                s = s.replace("\\\"", "\"").replace("\\\\", "\\");
            }
        }
        return s;
    }

    // ---- util --------------------------------------------------------------------------

    /** Palavra inteira quando a regra comeca e termina em letra ou numero; senao, em qualquer lugar. */
    static String typeFor(String pattern) {
        if (pattern.isEmpty()) {
            return "0";
        }
        final int a = pattern.codePointAt(0);
        final int b = pattern.codePointBefore(pattern.length());
        return Character.isLetterOrDigit(a) && Character.isLetterOrDigit(b) ? "2" : "0";
    }

    private static String unescape(String s) {
        if (s.indexOf('\\') < 0) {
            return s;
        }
        final Matcher m = HEX_ESCAPE.matcher(s);
        final StringBuffer out = new StringBuffer();
        while (m.find()) {
            final String hex = m.group(1) != null ? m.group(1) : m.group(2);
            m.appendReplacement(out, Matcher.quoteReplacement(String.valueOf((char) Integer.parseInt(hex, 16))));
        }
        m.appendTail(out);
        return out.toString();
    }
}
