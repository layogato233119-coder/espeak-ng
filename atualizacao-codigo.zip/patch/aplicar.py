#!/usr/bin/env python3
"""Aplica a marca "Diferente dos Normais / Android Todo Tempo" no codigo do eSpeak NG.

Rode na raiz do repositorio (onde existe a pasta android/):  python3 patch/aplicar.py
E seguro rodar mais de uma vez: cada alteracao confere se ja foi feita e,
se um ponto de ancoragem nao for encontrado, o script para e avisa.
"""
import os
import re
import shutil
import sys

# ---- ajuste aqui ------------------------------------------------------------
NOME_DO_APP = "eSpeak tts Diferente dos normais"
APPLICATION_ID = "br.com.androidtodotempo.diferentedosnormais"
LINK_WHATSAPP = "https://chat.whatsapp.com/EhICbjp4XlwErfKKNoGmJn?s=cl&p=a&mlu=4&iam=0"
# -----------------------------------------------------------------------------

AQUI = os.path.dirname(os.path.abspath(__file__))
ANDROID = "android"


def ler(caminho):
    with open(caminho, encoding="utf-8") as f:
        return f.read()


def gravar(caminho, texto):
    with open(caminho, "w", encoding="utf-8", newline="") as f:
        f.write(texto)


def falhar(msg):
    sys.exit("ERRO em aplicar.py: " + msg)


def editar(caminho, funcao):
    if not os.path.isfile(caminho):
        falhar("arquivo nao encontrado: " + caminho)
    antes = ler(caminho)
    depois = funcao(antes)
    if depois != antes:
        gravar(caminho, depois)
        print("alterado:", caminho)
    else:
        print("ja estava aplicado:", caminho)


# 1. applicationId proprio -------------------------------------------------------
def build_gradle(s):
    if "applicationId" in s:
        return s
    novo, n = re.subn(r'(\n[ \t]*)(minSdk\s*=\s*\d+)',
                      lambda m: m.group(1) + 'applicationId "%s"' % APPLICATION_ID + m.group(1) + m.group(2),
                      s, count=1)
    if n == 0:
        falhar("minSdk nao encontrado em build.gradle")
    return novo


# 2. nome do app -----------------------------------------------------------------
def nome_app(s):
    novo, n = re.subn(r'(<string name="app_name"[^>]*>)[^<]*(</string>)',
                      lambda m: m.group(1) + NOME_DO_APP + m.group(2), s, count=1)
    if n == 0:
        falhar("app_name nao encontrado")
    return novo


# 3. manifesto: tela de boas-vindas vira a tela inicial --------------------------
ATIVIDADE = '''<activity
            android:name=".WelcomeActivity"
            android:theme="@style/AppTheme"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        '''


def manifesto(s):
    if ".WelcomeActivity" in s:
        return s
    s, n = re.subn(r'\s*<intent-filter>\s*<action android:name="android\.intent\.action\.MAIN"\s*/>\s*'
                   r'<category android:name="android\.intent\.category\.LAUNCHER"\s*/>\s*</intent-filter>',
                   '', s, count=1)
    if n == 0:
        falhar("filtro MAIN/LAUNCHER nao encontrado no AndroidManifest.xml")
    s, n = re.subn(r'(<activity\s+android:name="\.TtsSettingsActivity")',
                   lambda m: ATIVIDADE + m.group(1), s, count=1)
    if n == 0:
        falhar("TtsSettingsActivity nao encontrada no AndroidManifest.xml")
    return s


# 4. linhas novas nas configuracoes (tela Backup e sobre) -------------------------
CATEGORIA = '''<com.animeshahilya.espeakng.preference.AccessiblePreferenceCategory
          android:title="@string/todo_category"
          app:iconSpaceReserved="false">
        <Preference
            android:key="action_todo_tempo_menu"
            android:title="@string/todo_menu_title"
            android:summary="@string/todo_menu_summary"
            app:iconSpaceReserved="false" />
        <Preference
            android:key="action_system_voices"
            android:title="@string/system_voices_title"
            android:summary="@string/system_voices_summary"
            app:iconSpaceReserved="false" />
        <Preference
            android:key="action_welcome"
            android:title="@string/welcome_row_title"
            app:iconSpaceReserved="false" />
      </com.animeshahilya.espeakng.preference.AccessiblePreferenceCategory>
      '''


def preferencias(s):
    if "action_todo_tempo_menu" in s:
        return s
    s, n = re.subn(r'(<com\.animeshahilya\.espeakng\.preference\.AccessiblePreferenceCategory\s+'
                   r'android:title="@string/category_about")',
                   lambda m: CATEGORIA + m.group(1), s, count=1)
    if n == 0:
        falhar("categoria 'Sobre' nao encontrada em preferences.xml")
    return s


# 5. ligacoes no TtsSettingsActivity ---------------------------------------------
def atividade(s):
    if "TodoTempo." in s:
        return s
    s, n = re.subn(r'([ \t]*)(onClick\(screen, "action_about", \(\) -> showAboutDialog\(context\)\);)',
                   lambda m: m.group(1) + "TodoTempo.wire(context, screen);\n" + m.group(1) + m.group(2),
                   s, count=1)
    if n == 0:
        falhar('ancora "action_about" nao encontrada em TtsSettingsActivity.java')
    # dicionario: cada arquivo importado vira um dicionario separado (DictionaryPacks)
    alvo = "added = UserDictionaryManager.getInstance(activity).importFromStream(is);"
    if alvo not in s:
        falhar("ancora da importacao do dicionario nao encontrada")
    s = s.replace(alvo, "added = DictionaryPacks.importBytes(DictionaryPacks.get(activity),\n"
                        "                                DictionaryFormats.readAll(is, 64 << 20),\n"
                        "                                DictionaryFormats.displayName(activity, uri)).rules;", 1)
    # grupo de comentarios do WhatsApp: o da comunidade Android Todo Tempo
    s, n = re.subn(r'(FEEDBACK_GROUP_URL\s*=\s*)"[^"]*"', lambda m: m.group(1) + '"%s"' % LINK_WHATSAPP, s, count=1)
    if n == 0:
        falhar("FEEDBACK_GROUP_URL nao encontrada")
    return s


# 5b. vozes incluidas no APK: instalar ao iniciar o app ---------------------------
def aplicativo(s):
    if "BundledVoices." in s:
        return s
    s, n = re.subn(r'([ \t]*)(EspeakApp\.storageContext = appContext\.createDeviceProtectedStorageContext\(\);)',
                   lambda m: m.group(1) + m.group(2) + "\n" + m.group(1) + "BundledVoices.installAsync(appContext);",
                   s, count=1)
    if n == 0:
        falhar("ancora do storageContext nao encontrada em EspeakApp.java")
    return s


# 6. traducao pt-BR --------------------------------------------------------------
BLOCO = re.compile(r'<(string|string-array|plurals) name="(\w+)"[^>]*>.*?</\1>', re.S)


def traducao(s):
    extra = ler(os.path.join(AQUI, "pt-BR-extra.xml"))
    existentes = {m.group(2): m for m in BLOCO.finditer(s)}
    novos = []
    for m in BLOCO.finditer(extra):
        nome = m.group(2)
        if nome in existentes:
            # o texto de novidades do app original e substituido; os demais ficam como estao
            if nome == "whats_new_body" and "Android Todo Tempo" not in existentes[nome].group(0):
                s = s.replace(existentes[nome].group(0), "")
            else:
                continue
        novos.append("  " + m.group(0))
    if not novos:
        return s
    return s.replace("</resources>", "\n".join(novos) + "\n</resources>")


# 7. versionCode crescente: atualizar por cima exige numero maior a cada versao ----
def version_code(s):
    if "DN_VERSION_CODE" in s:
        return s
    novo, n = re.subn(r'versionCode\s*=\s*(\d+)',
                      lambda m: 'versionCode = (System.getenv("DN_VERSION_CODE") ?: "%s").toInteger()' % m.group(1),
                      s, count=1)
    if n == 0:
        falhar("versionCode nao encontrado em build.gradle")
    return novo


# 8. vozes .onnx dentro do APK sem recompressao (abre mais rapido, nao estoura memoria) --------
def sem_compressao(s):
    if '"onnx"' in s:
        return s
    novo, n = re.subn(r'([ \t]*)(noCompress \+= "espeakdata\.zip")',
                      lambda m: m.group(1) + m.group(2) + "\n" + m.group(1) + 'noCompress += "onnx"',
                      s, count=1)
    if n == 0:
        falhar("noCompress nao encontrado em build.gradle")
    return novo


# 9. dicionarios importados lado a lado ---------------------------------------------
LINHA_PACOTES = '''
    <Preference
        android:key="action_dictionary_packs"
        android:title="@string/packs_title"
        android:summary="@string/packs_summary"
        android:icon="@drawable/ic_dictionary" />'''


def preferencias_pacotes(s):
    if "action_dictionary_packs" in s:
        return s
    novo, n = re.subn(r'(android:key="espeak_user_dictionary"[^>]*?android:icon="@drawable/ic_dictionary"\s*/>)',
                      lambda m: m.group(1) + LINHA_PACOTES, s, count=1, flags=re.S)
    if n == 0:
        falhar("preferencia espeak_user_dictionary nao encontrada em preferences.xml")
    return novo


ATIVIDADE_PACOTES = '''<activity
            android:name=".DictionaryPacksActivity"
            android:theme="@style/AppTheme"
            android:exported="false" />
        '''


def manifesto_pacotes(s):
    if ".DictionaryPacksActivity" in s:
        return s
    novo, n = re.subn(r'(<activity\s+android:name="\.TtsSettingsActivity")',
                      lambda m: ATIVIDADE_PACOTES + m.group(1), s, count=1)
    if n == 0:
        falhar("TtsSettingsActivity nao encontrada no AndroidManifest.xml (pacotes)")
    return novo


PROVEDOR = '''<provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.dnshare"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/dn_share_paths" />
        </provider>
        '''


def manifesto_compartilhar(s):
    if ".dnshare" in s:
        return s
    novo, n = re.subn(r'(<activity\s+android:name="\.TtsSettingsActivity")',
                      lambda m: PROVEDOR + m.group(1), s, count=1)
    if n == 0:
        falhar("TtsSettingsActivity nao encontrada no AndroidManifest.xml (compartilhar)")
    return novo


def somente_portugues(s):
    if "PtBrOnly." in s:
        return s
    alvo = "final List<PiperDownloads.CatalogVoice> result = catalog;"
    if alvo not in s:
        falhar("ancora do catalogo de vozes nao encontrada em PiperSettings.java")
    return s.replace(alvo, "final List<PiperDownloads.CatalogVoice> result = PtBrOnly.filter(catalog);", 1)


def gerente_pacotes(s):
    if "applyOwnRules" in s:
        return s
    novo, n = re.subn(r'([ \t]*)public String applyRules\(String text, String language\) \{',
                      lambda m: (m.group(1) + "public String applyRules(String text, String language) {\n"
                                 + m.group(1) + "    return DictionaryPacks.get(mFilesDir).apply(applyOwnRules(text, language), language);\n"
                                 + m.group(1) + "}\n\n"
                                 + m.group(1) + "private String applyOwnRules(String text, String language) {"),
                      s, count=1)
    if n == 0:
        falhar("applyRules nao encontrado em UserDictionaryManager.java")
    novo, n = re.subn(r'([ \t]*)public String applyCharacterRule\(String text, String language\) \{',
                      lambda m: (m.group(1) + "public String applyCharacterRule(String text, String language) {\n"
                                 + m.group(1) + "    final String own = applyOwnCharacterRule(text, language);\n"
                                 + m.group(1) + "    if (own != null && !own.equals(text)) {\n"
                                 + m.group(1) + "        return own;\n"
                                 + m.group(1) + "    }\n"
                                 + m.group(1) + "    return DictionaryPacks.get(mFilesDir).applyCharacter(text, language);\n"
                                 + m.group(1) + "}\n\n"
                                 + m.group(1) + "private String applyOwnCharacterRule(String text, String language) {"),
                      novo, count=1)
    if n == 0:
        falhar("applyCharacterRule nao encontrado em UserDictionaryManager.java")
    return novo


def main():
    if not os.path.isdir(ANDROID):
        falhar("rode na raiz do repositorio (pasta android/ nao encontrada)")
    editar(os.path.join(ANDROID, "build.gradle"), build_gradle)
    editar(os.path.join(ANDROID, "res/values/donottranslate.xml"), nome_app)
    editar(os.path.join(ANDROID, "AndroidManifest.xml"), manifesto)
    editar(os.path.join(ANDROID, "res/xml/preferences.xml"), preferencias)
    editar(os.path.join(ANDROID, "src/com/animeshahilya/espeakng/TtsSettingsActivity.java"), atividade)
    editar(os.path.join(ANDROID, "src/com/animeshahilya/espeakng/EspeakApp.java"), aplicativo)
    editar(os.path.join(ANDROID, "build.gradle"), version_code)
    editar(os.path.join(ANDROID, "build.gradle"), sem_compressao)
    editar(os.path.join(ANDROID, "res/xml/preferences.xml"), preferencias_pacotes)
    editar(os.path.join(ANDROID, "AndroidManifest.xml"), manifesto_pacotes)
    editar(os.path.join(ANDROID, "AndroidManifest.xml"), manifesto_compartilhar)
    editar(os.path.join(ANDROID, "src/com/animeshahilya/espeakng/UserDictionaryManager.java"), gerente_pacotes)
    editar(os.path.join(ANDROID, "src/com/animeshahilya/espeakng/PiperSettings.java"), somente_portugues)
    os.makedirs(os.path.join(ANDROID, "res/values-pt-rBR"), exist_ok=True)
    caminho_pt = os.path.join(ANDROID, "res/values-pt-rBR/strings.xml")
    editar(caminho_pt, traducao)
    shutil.copytree(os.path.join(AQUI, "novos"), ".", dirs_exist_ok=True)
    print("arquivos novos copiados")
    print("OK: marca aplicada.")


if __name__ == "__main__":
    main()
