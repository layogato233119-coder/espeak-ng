#!/usr/bin/env python3
"""Converte o modelo da Miro (ONNX opset 17) para opset 15, como as vozes Piper comuns:
troca cada LayerNormalization por operacoes basicas e baixa a versao do opset de 17 para 15.
Sem dependencias. Uso: patch_model.py entrada.onnx saida.onnx"""
import struct, sys, mmap

def rv(b, i):
    r = 0; s = 0
    while True:
        c = b[i]; i += 1; r |= (c & 0x7f) << s; s += 7
        if not c & 0x80: return r, i

def wv(n):
    out = bytearray()
    while True:
        c = n & 0x7f; n >>= 7
        if n: out.append(c | 0x80)
        else: out.append(c); return bytes(out)

def fields(b, start, end):
    """(campo, wiretype, inicio_do_tag, inicio_do_payload, fim)"""
    i = start
    while i < end:
        t0 = i
        k, i = rv(b, i); fn = k >> 3; wt = k & 7
        if wt == 0:
            _, j = rv(b, i); yield fn, wt, t0, i, j; i = j
        elif wt == 2:
            l, j = rv(b, i); yield fn, wt, t0, j, j + l; i = j + l
        elif wt == 1: yield fn, wt, t0, i, i + 8; i += 8
        elif wt == 5: yield fn, wt, t0, i, i + 4; i += 4
        else: raise SystemExit('wiretype inesperado %d' % wt)

def ld(fn, payload): return wv((fn << 3) | 2) + wv(len(payload)) + payload
def vi(fn, v): return wv(fn << 3) + wv(v)
def s_(fn, text): return ld(fn, text.encode())

def tensor_scalar_float(v):
    return vi(2, 1) + ld(9, struct.pack('<f', v))          # data_type FLOAT, raw_data

def attr_ints(name, vals):
    return ld(5, s_(1, name) + b''.join(vi(8, x & 0xFFFFFFFFFFFFFFFF) for x in vals) + vi(20, 7))
def attr_int(name, v):
    return ld(5, s_(1, name) + vi(3, v & 0xFFFFFFFFFFFFFFFF) + vi(20, 2))
def attr_tensor(name, t):
    return ld(5, s_(1, name) + ld(5, t) + vi(20, 4))

def node(op, ins, outs, name, attrs=b''):
    body = b''.join(s_(1, x) for x in ins) + b''.join(s_(2, x) for x in outs) + s_(3, name) + s_(4, op) + attrs
    return ld(1, body)

def decompose_ln(m, a, b):
    ins = []; outs = []; name = ''; axis = -1; eps = 1e-5
    for fn, wt, t0, p0, p1 in fields(m, a, b):
        if fn == 1: ins.append(bytes(m[p0:p1]).decode())
        elif fn == 2: outs.append(bytes(m[p0:p1]).decode())
        elif fn == 3: name = bytes(m[p0:p1]).decode()
        elif fn == 5:
            an = None; av = None
            for f2, w2, u0, q0, q1 in fields(m, p0, p1):
                if f2 == 1: an = bytes(m[q0:q1]).decode()
                elif f2 == 2 and w2 == 5: av = struct.unpack('<f', bytes(m[q0:q1]))[0]
                elif f2 == 3 and w2 == 0: av = rv(m, q0)[0]
            if an == 'axis':
                axis = av - (1 << 64) if av >= (1 << 63) else av
            elif an == 'epsilon': eps = av
    if len(outs) != 1: raise SystemExit('LayerNormalization com mais de uma saida em ' + name)
    x, scale = ins[0], ins[1]; bias = ins[2] if len(ins) > 2 and ins[2] else None
    p = name + '/dn_'
    ns = [
        node('ReduceMean', [x], [p + 'mean'], p + 'n1', attr_ints('axes', [axis]) + attr_int('keepdims', 1)),
        node('Sub', [x, p + 'mean'], [p + 'd'], p + 'n2'),
        node('Mul', [p + 'd', p + 'd'], [p + 'sq'], p + 'n3'),
        node('ReduceMean', [p + 'sq'], [p + 'var'], p + 'n4', attr_ints('axes', [axis]) + attr_int('keepdims', 1)),
        node('Constant', [], [p + 'eps'], p + 'n5', attr_tensor('value', tensor_scalar_float(eps))),
        node('Add', [p + 'var', p + 'eps'], [p + 've'], p + 'n6'),
        node('Sqrt', [p + 've'], [p + 'sd'], p + 'n7'),
        node('Div', [p + 'd', p + 'sd'], [p + 'nrm'], p + 'n8'),
    ]
    if bias:
        ns += [node('Mul', [p + 'nrm', scale], [p + 'sc'], p + 'n9'),
               node('Add', [p + 'sc', bias], [outs[0]], p + 'n10')]
    else:
        ns += [node('Mul', [p + 'nrm', scale], [outs[0]], p + 'n9')]
    return b''.join(ns), len(ns)

def patch(src, dst):
    f = open(src, 'rb'); m = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
    out = bytearray(); count = 0; opset_fixed = False
    for fn, wt, t0, p0, p1 in fields(m, 0, len(m)):
        if fn == 8 and wt == 2:
            dom = None; ver = None
            for f2, w2, u0, q0, q1 in fields(m, p0, p1):
                if f2 == 1: dom = bytes(m[q0:q1]).decode()
                if f2 == 2: ver = rv(m, q0)[0]
            if dom == '' and ver and ver > 15:
                out += ld(8, s_(1, '') + vi(2, 15)); opset_fixed = True
                continue
        if fn == 7 and wt == 2:
            g = bytearray()
            for g_fn, g_wt, g0, gp0, gp1 in fields(m, p0, p1):
                if g_fn == 1 and g_wt == 2:
                    op = None; dom = ''
                    for f2, w2, u0, q0, q1 in fields(m, gp0, gp1):
                        if f2 == 4: op = bytes(m[q0:q1]).decode()
                        if f2 == 7: dom = bytes(m[q0:q1]).decode()
                    if op == 'LayerNormalization' and dom == '':
                        new, _ = decompose_ln(m, gp0, gp1); g += new; count += 1
                        continue
                g += m[g0:gp1]
            out += ld(7, bytes(g)); continue
        out += m[t0:p1]
    if not opset_fixed: raise SystemExit('opset 17 nao encontrado')
    open(dst, 'wb').write(out)
    return count

if __name__ == '__main__':
    n = patch(sys.argv[1], sys.argv[2])
    print('LayerNormalization trocadas:', n)
