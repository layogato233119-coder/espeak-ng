#!/usr/bin/env python3
"""Roda na compilacao (dentro do aplicar.py). Para cada voz em vozes/<nome>/:
 1. junta as partes modelo.onnx.parteN (ou usa modelo.onnx);
 2. se o arquivo estiver quebrado (ex.: uma parte enviada cortada), recupera a parte boa do historico do git;
 3. se o modelo for opset > 15 (como a Miro), converte para opset 15 (patch_model.py);
 4. regrava as partes e, se o modelo ja estiver copiado para o app, atualiza la tambem.
Seguro para rodar varias vezes: modelo ja convertido e valido nao e mexido."""
import glob, hashlib, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import patch_model as pm


def aviso(msg):
    print('[miro_fix] ' + msg, flush=True)


def parse_info(data):
    """(valido, opset_ai_onnx). Valido = estrutura protobuf completa com grafo."""
    try:
        has_graph = False; opset = None; end = 0
        for fn, wt, t0, p0, p1 in pm.fields(data, 0, len(data)):
            end = p1
            if fn == 7 and wt == 2:
                has_graph = True
            if fn == 8 and wt == 2:
                dom = None; ver = None
                for f2, w2, u0, q0, q1 in pm.fields(data, p0, p1):
                    if f2 == 1: dom = bytes(data[q0:q1]).decode()
                    if f2 == 2: ver = pm.rv(data, q0)[0]
                if dom == '': opset = ver
        return (end == len(data) and has_graph and opset is not None), opset
    except Exception:
        return False, None


def sh(args, cwd):
    return subprocess.run(args, cwd=cwd, capture_output=True, text=True)


def parts_of(folder):
    ps = glob.glob(os.path.join(folder, 'modelo.onnx.parte*'))
    ps.sort(key=lambda p: int(re.findall(r'(\d+)$', p)[0]) if re.findall(r'(\d+)$', p) else 0)
    return ps


def read_model(folder):
    ps = parts_of(folder)
    if ps:
        return ps, b''.join(open(p, 'rb').read() for p in ps)
    single = os.path.join(folder, 'modelo.onnx')
    if os.path.exists(single):
        return [single], open(single, 'rb').read()
    return [], b''


def restore_from_history(root, folder, ps):
    """Tenta trocar partes quebradas por versoes boas do historico do git."""
    rel = [os.path.relpath(p, root) for p in ps]
    sh(['git', 'fetch', '--depth=300', 'origin'], root)
    sh(['git', 'fetch', '--unshallow'], root)
    good = {}
    for r in rel:
        log = sh(['git', 'log', '--all', '--format=%H', '--', r], root)
        cands = []
        for h in log.stdout.split():
            size = sh(['git', 'cat-file', '-s', h + ':' + r], root)
            if size.returncode == 0 and size.stdout.strip().isdigit():
                cands.append((h, int(size.stdout.strip())))
        good[r] = cands
    # tenta, para cada parte, o blob grande mais recente; confere o modelo inteiro no fim
    cur = {}
    for r in rel:
        cur[r] = open(os.path.join(root, r), 'rb').read()
    sizes = [len(v) for v in cur.values()]
    big = max(sizes)
    for r in rel:
        if len(cur[r]) < big * 0.5:
            for h, sz in good[r]:
                if sz >= big * 0.5:
                    blob = subprocess.run(['git', 'show', h + ':' + r], cwd=root, capture_output=True).stdout
                    if len(blob) == sz:
                        cur[r] = blob
                        aviso('parte %s recuperada do historico (%s, %d bytes)' % (r, h[:7], sz))
                        break
    return b''.join(cur[r] for r in rel), cur


def write_parts(ps, data):
    n = len(ps)
    if n == 1:
        open(ps[0], 'wb').write(data); return
    step = len(data) // n
    for i, p in enumerate(ps):
        a = i * step; b = len(data) if i == n - 1 else (i + 1) * step
        open(p, 'wb').write(data[a:b])


def run(root):
    voices = [d for d in glob.glob(os.path.join(root, 'vozes', '*')) if os.path.isdir(d)]
    for folder in voices:
        name = os.path.basename(folder)
        ps, data = read_model(folder)
        if not ps:
            continue
        valid, opset = parse_info(data)
        if not valid and len(ps) > 1:
            aviso('%s: modelo quebrado; procurando partes boas no historico' % name)
            try:
                data2, cur = restore_from_history(root, folder, ps)
                data = data2
                valid, opset = parse_info(data)
            except Exception as e:
                aviso('nao consegui recuperar: %s' % e)
        if not valid:
            aviso('%s: ATENCAO, modelo invalido; nada foi alterado' % name)
            continue
        if opset and opset > 15:
            aviso('%s: convertendo opset %d -> 15' % (name, opset))
            with tempfile.TemporaryDirectory() as td:
                src = os.path.join(td, 'in.onnx'); dst = os.path.join(td, 'out.onnx')
                open(src, 'wb').write(data)
                n = pm.patch(src, dst)
                data = open(dst, 'rb').read()
            aviso('%s: %s' % (name, 'LayerNormalization trocadas: %d' % n))
            valid, opset = parse_info(data)
            if not valid or opset != 15:
                aviso('%s: ATENCAO, conversao falhou; nada foi alterado' % name); continue
        # regrava as partes se mudou
        if data != read_model(folder)[1]:
            write_parts(ps, data)
            aviso('%s: partes atualizadas (%d bytes)' % (name, len(data)))
        # modelo ja copiado para o app (montagem anterior a este passo)
        asset = os.path.join(root, 'android', 'assets', 'vozes-incluidas', name, 'model.onnx')
        if os.path.isdir(os.path.dirname(asset)) and (not os.path.exists(asset) or os.path.getsize(asset) != len(data)
                or hashlib.sha256(open(asset, 'rb').read()).digest() != hashlib.sha256(data).digest()):
            open(asset, 'wb').write(data)
            aviso('%s: modelo do app atualizado' % name)


if __name__ == '__main__':
    run(sys.argv[1] if len(sys.argv) > 1 else os.getcwd())
